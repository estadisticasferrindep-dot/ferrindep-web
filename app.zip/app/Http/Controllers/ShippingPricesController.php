<?php

namespace App\Http\Controllers;

use App\Models\Pesozona;
use Illuminate\Http\Request;
use App\Models\Zona;


class ShippingPricesController extends Controller {
    public function index(){
        $zonas = Zona::orderBy('nombre')->get();
        $pesos = [ 0.5, 1, 2, 3, 5, 10, 15, 20, 25 ];

        $prices = Pesozona::orderBy('zona_id')->orderBy('peso')->get()->mapWithKeys(function($item) {
            return [$item->zona_id . '-' . floatval($item->peso) => $item->costo];
        });
        return view('shipping-prices.index', compact('zonas', 'pesos', 'prices'));
    }

    public function store() {
        foreach (request()->prices as $key => $price) {
            list($zona_id, $peso) = explode('-', $key);
            $pesozona = Pesozona::firstOrCreate([
                'zona_id' => $zona_id,
                'peso' => $peso
            ]);
            $pesozona->costo = $price;
            $pesozona->save();
        }
        return redirect()->route('shipping-prices')->with('info','Los precios de envío han sido actualizados');
    }
}
