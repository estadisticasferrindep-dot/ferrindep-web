<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pedido;

class PedidoController extends Controller
{
    /**
     * Lista de pedidos:
     * - Eager-load de itemsPedidos para evitar N+1
     * - Orden descendente (más nuevos primero)
     * - Paginación (ajustá 50/100/200 a gusto)
     */
    public function index()
    {
        $pedidos = Pedido::with('itemsPedidos')
            ->orderBy('created_at', 'desc')
            ->orderBy('id', 'desc')
            ->paginate(100);

        return view('pedidos.index', compact('pedidos'));
    }

    public function create()
    {
        return view('pedidos.create');
    }

    public function store(Request $request)
    {
        $pedidos = Pedido::create($request->all());

        if ($request->hasFile('imagen')) {
            $imagen = $request->file('imagen')->store('public/pedidos');
            $pedidos->imagen = $imagen;
        }

        $pedidos->save();

        return redirect()->route('pedidos.index')->with('info','Pedido agregado con éxito');
    }

    public function edit(Pedido $pedido)
    {
        return view('pedidos.edit', compact('pedido'));
    }

    public function update(Request $request, Pedido $pedido)
    {
        $pedido->update($request->all());

        if ($request->hasFile('imagen')) {
            $imagen = $request->file('imagen')->store('public/pedidos');
            $pedido->imagen = $imagen;
        }

        if (!$request->show) {
            $pedido->show = 0;
        }

        if (!$request->home) {
            $pedido->home = 0;
        }

        $pedido->save();

        return redirect()->route('pedidos.index')->with('info','Pedido actualizado con éxito');
    }

    public function destroy(Pedido $pedido)
    {
        $pedido->delete();
        return redirect()->route('pedidos.index');
    }
}
