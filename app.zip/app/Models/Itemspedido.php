<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Itemspedido extends Model
{
    use HasFactory;

    protected $guarded = [];

    // public function colorNombre()
    // {
    //     return Galeria::find($this->color)->nombre;
    // }
}
