@extends('layouts.plantilla')

@section('title','Compra realizada con éxito')

@section('content')


<section class="section-clientes">
    <div class="container">
        <div class="row">
            <h1>¡Gracias por su compra!</h1>
        <div>
    </div>

</section>

@endsection