@extends('layouts.plantilla')

@section('title','¡Compra Exitosa!')

@section('content')

<section class="section-clientes" style="padding: 60px 0; background-color: #f4f4f4;">
    <div class="container text-center">
        
        <div style="margin: 0 auto 20px auto; width: 80px; height: 80px;">
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130.2 130.2">
                <circle class="path circle" fill="#4CAF50" cx="65.1" cy="65.1" r="62.1"/>
                <polyline class="path check" fill="none" stroke="#FFFFFF" stroke-width="8" stroke-linecap="round" stroke-miterlimit="10" points="100.2,40.2 51.5,88.8 29.8,67.5 "/>
            </svg>
        </div>

        <h1 style="font-family: 'Open Sans', sans-serif; font-weight: 700; margin-bottom: 10px; color: #333333;">¡Gracias por su compra!</h1>
        <p style="font-family: 'Open Sans', sans-serif; color: #666666; margin-bottom: 10px;">Su pedido ha sido registrado correctamente.</p>
        
        <div style="background-color: #e3f2fd; border: 1px solid #bbdefb; color: #0d47a1; padding: 12px 20px; border-radius: 50px; font-size: 14px; display: inline-block; margin-top: 10px;">
            Hemos enviado un detalle de su orden de compra por email, <strong>por favor revisar spam</strong>.
        </div>

        <div style="height: 40px;"></div>

        @if(isset($pedido))
        <div style="background-color: #ffffff !important; border: 1px solid #cccccc !important; border-radius: 8px; overflow: hidden; max-width: 700px; margin: 0 auto; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
            
            <div style="background-color: #000000 !important; color: #ffffff !important; padding: 15px 25px; border-bottom: 4px solid #F37021; display: flex; justify-content: space-between; align-items: center;">
                <span style="text-transform: uppercase; font-size: 14px; font-weight: 600;">ORDEN CONFIRMADA</span>
                <span style="color: #F37021; font-size: 18px; font-weight: bold;">#{{ $pedido->id }}</span>
            </div>

            <div style="padding: 30px; text-align: left;">
                <div class="row">
                    <div class="col-md-6" style="margin-bottom: 20px;">
                        <span style="font-size: 11px; color: #999; text-transform: uppercase; font-weight: bold; display: block; margin-bottom: 5px;">Cliente</span>
                        <div style="font-size: 16px; font-weight: 600; color: #333;">{{ $pedido->usuario_nombre ?? $pedido->nombre }}</div>
                        <div style="font-size: 14px; color: #666;">{{ $pedido->usuario_email ?? $pedido->email }}</div>
                    </div>

                    <div class="col-md-6" style="margin-bottom: 20px;">
                        <span style="font-size: 11px; color: #999; text-transform: uppercase; font-weight: bold; display: block; margin-bottom: 5px;">Forma de Entrega</span>
                        <div style="font-size: 16px; font-weight: 600; color: #333;">
                            @if($pedido->envio == 'fabrica') Retiro en Depósito @else Envío a Domicilio @endif
                        </div>
                        <div style="font-size: 13px; color: #666; margin-top: 3px;">
                            {{ $pedido->localidad_envio ?? 'CABA / GBA' }}
                        </div>
                    </div>
                </div>
                
                <hr style="border: 0; border-top: 1px dashed #ddd; margin: 20px 0;">

                <div style="text-align: right;">
                    <span style="font-size: 12px; color: #999; text-transform: uppercase; font-weight: bold; display: block;">Importe Total</span>
                    <div style="font-size: 28px; color: #F37021; font-weight: bold;">${{ number_format($pedido->total, 2, ',', '.') }}</div>
                </div>
            </div>
        </div>
        @endif

        <div style="margin-top: 50px; display: flex; justify-content: center; gap: 15px; flex-wrap: wrap;">
            
            <a href="{{ route('web.home') }}" style="background-color: #F37021 !important; color: #ffffff !important; border: none; padding: 12px 30px; border-radius: 50px; font-weight: bold; text-decoration: none; display: inline-block; font-size: 14px;">
                Volver a la Tienda
            </a>
            
            <a href="https://wa.me/5491132631520?text=Hola,%20acabo%20de%20realizar%20el%20pedido%20#{{ isset($pedido) ? $pedido->id : '' }}%20y%20quería%20consultar..." target="_blank" style="background-color: #25D366 !important; color: #ffffff !important; border: none; padding: 12px 30px; border-radius: 50px; font-weight: bold; text-decoration: none; display: inline-block; font-size: 14px;">
                Contactar por WhatsApp
            </a>

        </div>

    </div>
</section>

<style>
    @keyframes popIn { 0% { transform: scale(0); opacity: 0; } 80% { transform: scale(1.1); opacity: 1; } 100% { transform: scale(1); } }
    .section-clientes svg { animation: popIn 0.6s cubic-bezier(0.68, -0.55, 0.27, 1.55) forwards; }
</style>

@endsection