@extends('layouts.plantilla')

@section('title','Ferrindep')

@section('content')

<div id="carouselExampleIndicators" class="carousel carousel-home slide " data-bs-ride="carousel">
  <div class="carousel-indicators">
    @foreach ($imagenes as $key=>$imagen)     
      <button type="button" data-bs-target="#carouselExampleIndicators" class="{{$loop->first ? 'active' : ''}} btn-carousel" data-bs-slide-to="{{$key}}" {{$loop->first ? 'aria-current="true"' : ''}}  aria-label="Slide {{$key}}"></button>
    @endforeach
  </div>

  <div class="carousel-inner">
    @foreach ($imagenes as $imagen)
      <div class="carousel-item {{$loop->first ? 'active' : ''}}" style="background-image:url({{asset(Storage::url($imagen->imagen))}})">
        <div class="carousel-overlay"></div>
        <div class="carousel-caption d-none d-md-block carousel-texto" style="bottom:7.25rem">
          <h2 class="texto-empresa">{!!$imagen->texto!!}</h2>
        </div>
      </div>
    @endforeach
  </div>
</div>
<div class="data-home d-none d-md-flex">
  <div class="container">
    <div class="row">
      <div class="col-4" style="display:flex">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12 col-lg-4 mt-4 mt-md-0">
              <img src="{{asset(Storage::url($home->seccion_foto1))}}">
            </div>
            <div class="col-12 col-lg-8 d-md-flex flex-wrap text-center text-md-left mt-2 mt-lg-0 home-mobile">
              <h3>{{$home->seccion_titulo1}}</h3>
              <h5>{{$home->seccion_texto1}}</h5>
            </div>
          </div>
        </div>
      </div>

      <div class="col-4" style="display:flex">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12 col-lg-4 mt-4 mt-md-0 home-mobile">
              <img src="{{asset(Storage::url($home->seccion_foto2))}}">
            </div>
            <div class="col-12 col-lg-8 d-md-flex flex-wrap text-center text-md-left mt-2 mt-lg-0 home-mobile">
              <h3>{{$home->seccion_titulo2}}</h3>
              <h5>{{$home->seccion_texto2}}</h5>
            </div>
          </div>
        </div>
      </div>

      <div class="col-4" style="display:flex">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12 col-lg-4 mt-4 mt-md-0 home-mobile">
              <img src="{{asset(Storage::url($home->seccion_foto3))}}">
            </div>
            <div class="col-12 col-lg-8 d-md-flex flex-wrap text-center text-md-left mt-2 mt-lg-0 home-mobile" style="padding:0;">
              <h3>{{$home->seccion_titulo3}}</h3>
              <h5>{{$home->seccion_texto3}}</h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>    
</div>

<div class="container" style="margin: 20px auto 15px;">
    <div class="card p-3 p-md-4 shadow-sm" style="border: none; background-color: #f8f9fa;">
        
        <h5 class="text-center" style="margin-bottom: 20px; font-weight: bold; color: #444; font-size: 1.2rem; font-family: 'Open Sans', sans-serif;">
            Buscador r&aacute;pido
        </h5>

        <div class="d-flex justify-content-center mb-3 mb-md-4">
            <div class="btn-group" role="group" style="width: 100%; max-width: 500px;"> 
                
                <button type="button" 
                        class="btn btn-outline-primary active px-1 px-md-4 py-2 btn-familia" 
                        data-familia-id="1" 
                        style="font-weight: 600; border-radius: 20px 0 0 20px; font-size: 13px; line-height: 1.2;">
                    <span class="d-none d-md-inline" style="font-size: 16px;">Mallas Electrosoldadas</span> 
                    <span class="d-inline d-md-none">Mallas<br>Electrosoldadas</span> 
                </button>

                <button type="button" 
                        class="btn btn-outline-primary px-1 px-md-4 py-2 btn-familia" 
                        data-familia-id="2" 
                        style="font-weight: 600; border-radius: 0 20px 20px 0; font-size: 13px; line-height: 1.2;">
                    <span class="d-none d-md-inline" style="font-size: 16px;">Metal Desplegado</span>
                    <span class="d-inline d-md-none">Metal<br>Desplegado</span>
                </button>

            </div>
        </div>
        
        </div> <h4 id="titulo-familia" class="text-center mt-2 mb-3" style="font-weight: 700; color: #0d6efd; font-family: 'Open Sans', sans-serif;">
            Mallas Electrosoldadas
        </h4>
    

        <form id="form-filtros">
            <div class="row g-2 g-md-3">
                
                <div class="col-6 col-md-3">
                    <label class="form-label text-muted font-weight-bold small mb-1">ANCHO DEL ROLLO</label>
                    <select id="filtro-ancho" class="form-select form-select-sm filtro-select">
                        <option value="" data-familia="all">Seleccionar</option>
                        @foreach($anchos as $ancho)
                            @php
                                $val = intval($ancho->nombre);
                                $texto = ($val >= 100) ? ($val/100) . ' m' : $val . ' cm';
                            @endphp
                            <option value="{{ $ancho->id }}" data-familia="{{ $ancho->familia_id }}">{{ $texto }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-6 col-md-3">
                    <label class="form-label text-muted font-weight-bold small mb-1">MEDIDA</label>
                    <select id="filtro-medida" class="form-select form-select-sm filtro-select">
                        <option value="" data-familia="all">Seleccionar</option>
                        @foreach($medidas as $medida)
                            <option value="{{ $medida->id }}" data-familia="{{ $medida->familia_id }}">{{ $medida->medidas }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-6 col-md-3">
                    <label id="label-espesor" class="form-label text-muted font-weight-bold small mb-1">ESPESOR (Alambre)</label>
                    <select id="filtro-espesor" class="form-select form-select-sm filtro-select">
                        <option value="" data-familia="all">Seleccionar</option>
                        @foreach($espesores as $espesor)
                            <option value="{{ $espesor->id }}" data-familia="{{ $espesor->familia_id }}">{{ $espesor->espesor }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-6 col-md-3 d-flex align-items-end">
                    <button type="button" id="btn-limpiar-filtros" class="btn btn-outline-secondary btn-sm w-100">
                        Limpiar
                    </button>
                </div>

            </div>
        </form>
    </div>
    
    <div id="msg-sin-resultados" class="alert alert-warning mt-3 d-none text-center py-2 small">
        No encontramos productos con esa combinaci��n en la familia seleccionada.
    </div>
</div>
<section class="section-home-categorias section-categoria" style="margin-bottom:58px;">
  <div class="container" style="margin-top:60px;">
    <div id="grid-productos" class="row">
        
       @php
          $mlGo = [ 1 => '/go/ml/10x10-30', 40 => '/go/ml/15x15-30', 54 => '/go/ml/25x25-30' ];
          $mlFallback = '/go/ml/tienda';
          $destacarTodos = true;
        @endphp

      @foreach ($productos as $item)
        @if ($item->destacado && $item->show)

          <div class="card-buscable d-none d-md-flex col-md-3" style="margin-bottom:40px;"
               data-familia="{{ $item->familia_id }}"
               data-ancho="{{ $item->categoria_id }}"
               data-medida="{{ $item->medida_id }}"
               data-espesor="{{ $item->espesor_id }}">
               
            <div style="border:1px solid rgba(143,134,110,.3); padding:8px; width:100%; height:100%;">
              <a href="{{ route('web.productos.producto',$item) }}" style="text-decoration:none">
                <div class="img-border-categorias img-active"
                     style="background-image:url({{asset(Storage::url($item->imagen))}});">
                  @if($item->oferta)
                    <div class="oferta">OFERTA</div>
                  @endif
                </div>
                <hr>
                <div class="text-box-categorias">
                  <div class="tabla-trabajo" style="font:normal 11px/16px Open Sans;color:#000;margin-top:0;">
                    <span style="font-size:120%">{{ $item->familia->nombre }}</span>
                  </div>

                  @if ($item->con_nombre)
                    <div class="tabla-trabajo" style="font: normal normal bold 18px/28px Open Sans; color: black;">
                      {{$item->nombre}}
                    </div>
                  @else
                    <div class="tabla-trabajo" style="font: normal normal bold 18px/28px Open Sans; color: black;">
                      {{$item->medidas->medidas}} {{$item->espesor->espesor}}
                    </div>
                  @endif

                  <div class="tabla-trabajo" style="font: normal normal bold 12px/17px Open Sans; color:#939292; margin-top:0;">
                    <span style="font-size:120%">
                      {{$item->categoria->con_nombre ? $item->categoria->nombre : (intval($item->categoria->nombre) >= 100 ? $item->categoria->nombre/100 .' m alto/ancho' : $item->categoria->nombre .' cm alto/ancho' ) }}
                    </span>
                  </div>

                  <hr>
                  <desde-categorias 
                    desc-efectivo="{{$configuracionPedidos->descuento_efectivo}}"
                    desc-transferencia="{{$configuracionPedidos->descuento_transferencia}}"
                    desc-mp="{{$configuracionPedidos->descuento_mp}}"
                    vendidos="{{$item->vendidos}}"
                    presentaciones="{{ $item->presentaciones }}"
                    oferta="{{$item->oferta}}"
                    con-nombre="{{$item->con_nombre}}"
                  />
                </div>
              </a>
            </div>
          </div>

          <div class="card-buscable d-flex d-md-none col-12" style="margin-bottom:0; padding:0;"
               data-familia="{{ $item->familia_id }}"
               data-ancho="{{ $item->categoria_id }}"
               data-medida="{{ $item->medida_id }}"
               data-espesor="{{ $item->espesor_id }}">
               
            <div style="border:1px solid rgba(143,134,110,.3); padding:7px 0; width:100%; height:100%;">
              <a href="{{ route('web.productos.producto',$item) }}" style="text-decoration:none">
                <div class="row">
                  <div class="col-4">
                    <div class="img-border-categorias img-active"
                         style="background-image:url({{asset(Storage::url($item->imagen))}});">
                      @if($item->oferta)
                        <div class="oferta">OFERTA</div>
                      @endif
                    </div>
                  </div>
                  <div class="col-8">
                    <div class="text-box-categorias"
                         style="display:flex; flex-direction:column; height:100%;
                                justify-content: {{ $destacarTodos ? 'flex-start' : 'space-between' }};">

                      <div class="tabla-trabajo" style="font:normal 11px/16px Open Sans;color:#000;margin-top:0;">
                        <span style="font-size:120%">{{ $item->familia->nombre }}</span>
                      </div>

                      <div>
                        @if ($item->con_nombre)
                          <div class="tabla-trabajo" style="color:#000; font-weight:700 !important; font-size:18px !important; line-height:24px !important;">
                            {{$item->nombre}}
                          </div>
                        @else
                          <div class="tabla-trabajo" style="color:#000; font-weight:700 !important; font-size:18px !important; line-height:24px !important;">
                            {{$item->medidas->medidas}} {{$item->espesor->espesor}}
                          </div>
                        @endif

                        <div class="tabla-trabajo" style="color:#939292; margin-top:2px; font-weight:700 !important; font-size:14px !important; line-height:18px !important;">
                          <span>
                            {{$item->categoria->con_nombre ? $item->categoria->nombre : (intval($item->categoria->nombre) >= 100 ? $item->categoria->nombre/100 .' m ancho' : $item->categoria->nombre .' cm ancho' ) }}
                          </span>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
              </a>

              @php
                $mlHref = $mlGo[$item->id] ?? $mlFallback;
              @endphp

              <div class="d-flex d-md-none" style="padding:0 12px; margin-top:6px; gap:6px; flex-wrap:nowrap; justify-content:flex-start;">
                <a href="{{ route('web.productos.producto', $item) }}" style="background:#16A34A; color:#fff; padding:6px 12px; border-radius:999px; text-decoration:none; font-weight:600; font-size:12px; line-height:1; white-space:nowrap; display:inline-flex; align-items:center;">
                  ver en Ferrindep
                </a>
                <a href="{{ $mlHref }}" target="_blank" rel="noopener" style="background:#FFE600; color:#111827; padding:6px 12px; border-radius:999px; text-decoration:none; font-weight:600; font-size:12px; line-height:1; white-space:nowrap; display:inline-flex; align-items:center;">
                  ver en MercadoLibre
                  <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" focusable="false" style="margin-left:6px; flex:0 0 14px;">
                    <circle cx="12" cy="12" r="10" fill="#2E7DFF"/>
                    <path d="M7.5 12.5l3 3 6-6" stroke="#fff" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </a>
              </div>

            </div>
          </div>

        @endif
      @endforeach

    </div>

    <div class="text-center">
      <a href="{{ route('web.productos.productos2',$familia_1) }}" style="text-decoration:none;">
        <button style="background:#FD914D;border:1px solid #FD914D;border-radius:8px;text-align:center;
                       font:bold 23px/26px Open Sans;letter-spacing:.56px;color:#fff;text-transform:uppercase;
                       margin-top:20px;padding:12px 55px;border:none;">
          VER TODOS LOS PRODUCTOS
        </button>
      </a>
    </div>

  </div>
</section>

<div class="col-12 video">
  <iframe width="100%" height="600px"
          src="https://www.youtube.com/embed/{{$home->video}}?loop=1&autoplay=1&playlist={{$home->video}}"
          title="YouTube video player" frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowfullscreen></iframe>
</div>

@endsection

{{-- =========================================================
   SCRIPT Y ESTILOS DE FILTRADO
   ========================================================= --}}
@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    
    // === REFERENCIAS DOM ===
    const selectAncho   = document.getElementById('filtro-ancho');
    const selectMedida  = document.getElementById('filtro-medida');
    const selectEspesor = document.getElementById('filtro-espesor');
    const labelEspesor  = document.getElementById('label-espesor');
    const btnLimpiar    = document.getElementById('btn-limpiar-filtros');
    const msgSinResult  = document.getElementById('msg-sin-resultados');
    const btnsFamilia   = document.querySelectorAll('.btn-familia');
    const cards         = document.querySelectorAll('.card-buscable');
    
    // Token de seguridad de Laravel (Necesario para enviar datos)
    const csrfToken = "{{ csrf_token() }}";

    // Estado inicial
    let familiaActiva = '1'; 
    let timeoutChismoso = null; // Para el temporizador del esp��a

    // ======================================================
    // �9�7�1�5�6�9��1�5 EL CHISMOSO: Funci��n para guardar b��squedas
    // ======================================================
    function activarElChismoso() {
        // 1. Si ya hab��a un env��o pendiente, lo cancelamos (reinicia el reloj)
        clearTimeout(timeoutChismoso);

        // 2. Esperamos 3 segundos antes de guardar (Debounce)
        timeoutChismoso = setTimeout(() => {
            
            // Validamos que haya seleccionado al menos ALGO (para no guardar vac��os)
            if (selectAncho.value === '' && selectMedida.value === '' && selectEspesor.value === '') {
                return; // Si no eligi�� nada, no guardamos.
            }

            // 3. Preparamos los datos
            // Sacamos el TEXTO de la opci��n seleccionada (ej: "10 x 10 mm"), no el ID
            const textoAncho   = selectAncho.selectedIndex   > 0 ? selectAncho.options[selectAncho.selectedIndex].text : null;
            const textoMedida  = selectMedida.selectedIndex  > 0 ? selectMedida.options[selectMedida.selectedIndex].text : null;
            const textoEspesor = selectEspesor.selectedIndex > 0 ? selectEspesor.options[selectEspesor.selectedIndex].text : null;
            const nombreFamilia = (familiaActiva == '1') ? 'Mallas Electrosoldadas' : 'Metal Desplegado';

            // 4. Enviamos los datos al servidor (AJAX)
            fetch('/guardar-busqueda', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                body: JSON.stringify({
                    familia:       nombreFamilia,
                    ancho_texto:   textoAncho,
                    medida_texto:  textoMedida,
                    espesor_texto: textoEspesor
                })
            })
            .then(response => {
                // Si quieres ver en la consola si funcion�� (F12):
                // console.log("Chismoso reportando: Guardado con ��xito."); 
            })
            .catch(error => console.error('Error del chismoso:', error));

        }, 3000); // 3000 ms = 3 segundos de espera
    }


    // ======================================================
    // �7�5�1�5 L�0�7GICA DE FILTRADO (Visual)
    // ======================================================

    function filtrarOpcionesDesplegables() {
        const selects = [selectAncho, selectMedida, selectEspesor];
        selects.forEach(sel => {
            const opciones = sel.querySelectorAll('option');
            opciones.forEach(opt => {
                const fam = opt.getAttribute('data-familia');
                if (fam === 'all') {
                    opt.style.display = '';
                    return;
                }
                // Nota: Usamos '==' para que coincida string con numero
                if (fam == familiaActiva) {
                    opt.style.display = '';
                    opt.disabled = false;
                } else {
                    opt.style.display = 'none';
                    opt.disabled = true;
                }
            });
            // Resetear si la opci��n elegida qued�� oculta
            const opcionActual = sel.options[sel.selectedIndex];
            if (opcionActual && opcionActual.getAttribute('data-familia') !== 'all' && opcionActual.getAttribute('data-familia') != familiaActiva) {
                sel.value = '';
            }
        });
    }

    function aplicarFiltros() {
        const valAncho   = selectAncho.value;
        const valMedida  = selectMedida.value;
        const valEspesor = selectEspesor.value;
        let visibles = 0;

        cards.forEach(card => {
            const cardFamilia = card.getAttribute('data-familia');
            const cardAncho   = card.getAttribute('data-ancho');
            const cardMedida  = card.getAttribute('data-medida');
            const cardEspesor = card.getAttribute('data-espesor');

            const matchFamilia = (cardFamilia == familiaActiva);
            const matchAncho   = (valAncho === '' || valAncho === cardAncho);
            const matchMedida  = (valMedida === '' || valMedida === cardMedida);
            const matchEspesor = (valEspesor === '' || valEspesor === cardEspesor);

            if (matchFamilia && matchAncho && matchMedida && matchEspesor) {
                card.classList.remove('filtro-oculto');
                if (card.classList.contains('col-md-3')) {
                    card.classList.add('d-md-flex'); 
                } else {
                    card.classList.add('d-flex');
                }
                visibles++;
            } else {
                card.classList.add('filtro-oculto');
                card.classList.remove('d-flex', 'd-md-flex');
            }
        });

        if (visibles === 0) {
            msgSinResult.classList.remove('d-none');
        } else {
            msgSinResult.classList.add('d-none');
        }

        // �7�2 �0�3AQU�0�1 ACTIVAMOS AL ESP�0�1A! Cada vez que se filtra, preparamos el reporte.
        activarElChismoso(); 
    }

    // --- EVENTOS ---
   // --- L�0�7GICA DE LOS BOTONES DE FAMILIA ---
    btnsFamilia.forEach(btn => {
        btn.addEventListener('click', function() {
            // 1. Obtenemos la familia seleccionada
            familiaActiva = this.getAttribute('data-familia-id');

            // 2. Visual botones (Pintar el activo)
            btnsFamilia.forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            // 3. CAMBIO DE TEXTOS (T��tulo y Label)
            const tituloFamilia = document.getElementById('titulo-familia');
            
            if (familiaActiva == '1') {
                // Si es Mallas
                labelEspesor.textContent = 'ESPESOR (Alambre)';
                tituloFamilia.textContent = 'Mallas Electrosoldadas'; // <--- CAMBIO AQU�0�1
            } else {
                // Si es Metal
                labelEspesor.textContent = 'ESPESOR';
                tituloFamilia.textContent = 'Metal Desplegado'; // <--- CAMBIO AQU�0�1
            }

            // 4. Filtrar opciones de los desplegables
            filtrarOpcionesDesplegables();

            // 5. Resetear valores y aplicar
            selectAncho.value = '';
            selectMedida.value = '';
            selectEspesor.value = '';
            aplicarFiltros();
        });
    });

    const selects = [selectAncho, selectMedida, selectEspesor];
    selects.forEach(sel => sel.addEventListener('change', aplicarFiltros));

    btnLimpiar.addEventListener('click', function() {
        selectAncho.value   = '';
        selectMedida.value  = '';
        selectEspesor.value = '';
        aplicarFiltros();
    });
    
    // Inicializaci��n
    filtrarOpcionesDesplegables();
    // Ejecutamos una vez sin activar el chismoso (para que cargue limpio)
    // aplicarFiltros llama al chismoso, pero como los valores est��n vac��os, el chismoso no guarda nada.
    aplicarFiltros(); 
});
</script>

<style>
    .filtro-oculto { display: none !important; }

    /* Estilos del candado (Selects) */
    #filtro-ancho, #filtro-medida, #filtro-espesor {
        font-weight: 400 !important;
        font-family: 'Open Sans', sans-serif !important;
        color: #555 !important;
        border: 1px solid #ced4da !important;
        outline: none !important;
        box-shadow: none !important;
    }
    #filtro-ancho option, #filtro-medida option, #filtro-espesor option {
        font-weight: 400 !important;
    }
</style>
@endsection