@extends('layouts.plantilla')

@section('title','Error')

@section('content')


<section class="section-clientes">
    <div class="container">
        <div class="row">
            <h1>Ha habido un error con su compra</h1>
            <p>Por favor inténtelo de nuevo</p>
        <div>
    </div>

</section>

@endsection