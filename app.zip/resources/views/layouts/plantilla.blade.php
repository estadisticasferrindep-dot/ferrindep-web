<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>

    <meta name="description" content="{{ $description }}">
    <meta name="keywords" content="{{ $keywords }}">
    <meta name="public-path" content="{{ asset('/') }}">

    <base href="{{ url('/') }}/">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- jQuery (para Slick) -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- Fuentes para el checkout -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- CSS propio -->
    <link href="{{ asset('css/style.css?v=20251115') }}" rel="stylesheet">
    <link href="{{ asset('css/grid.css?v=20251115') }}" rel="stylesheet">

    <!-- Slick CSS -->
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>

    <!-- Jodit CSS -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jodit/3.4.25/jodit.min.css">

    <style>
      .page-home section.section-home-categorias .card-buscable.home-hidden { display:none!important; }
      .page-home section.section-home-categorias .card-buscable.home-dim    { opacity:.35; filter:grayscale(100%); }
      .page-home section.section-home-categorias .card-buscable             { transition:opacity .2s ease; }
      .oferta, .sin_stock, [class*="ribbon"] { display:none!important; visibility:hidden!important; }

      /* === OCULTAR “Mi cuenta” EN MOBILE === */
      @media (max-width: 767.98px){
        .mobile-account { display:none !important; }
      }
    </style>

    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

    <script>
      function openProductModal (url, b) {
        setTimeout(() => {
          var el = document.getElementById('iframe-producto' + b);
          if (el) el.src = url;
        }, 300);
      }
    </script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=G-BWVDVM9X48"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-BWVDVM9X48');
    </script>
  </head>

  <body class="{{ (isset($breadcrumb[0]['title']) && $breadcrumb[0]['title'] === 'home') ? 'page-home' : '' }}">
    @php
      $isCarrito = request()->is('carrito');
      $isFinal   = request()->is('fin') || request()->is('finalizar-compra');
      $isCheckout= $isCarrito || $isFinal;
    @endphp

    @if($isCheckout)
      <style>
        /* Elevar CTA para evitar overlays que lo tapen */
        #btnSubmitPedido,
        button[form="formFinal"] {
          position: fixed!important;
          bottom: 24px!important;
          right: 24px!important;
          z-index: 2147483647!important;
          cursor: pointer!important;
        }

        /* Tipografías del checkout */
        .section-carrito h1,
        .section-carrito h2,
        .section-carrito h3 { font-family:"Montserrat","Open Sans",Arial,sans-serif!important; font-weight:700!important; letter-spacing:.2px; }
        .section-carrito, .section-carrito *:not(h1):not(h2):not(h3) { font-family:"Inter","Open Sans",Arial,sans-serif!important; }
        .section-carrito input, .section-carrito select, .section-carrito textarea, .section-carrito button { font-family:inherit!important; }
      </style>
    @endif

    <div id="app">
      <!-- HEADER -->
      <header>
        <nav>
          <div class="container nav-modal" style="display:flex;justify-content:space-between;">

            <a href="{{ route('web.home') }}" class="col-4 col-md-3" style="display:flex;align-items:center;">
              <img class="logo" src="{{ asset(Storage::url($home->logo)) }}" alt="Ferrindep" style="height:111px">
            </a>

            <button class="nav-btn d-flex d-md-none" data-bs-toggle="modal" data-bs-target="#exampleModal">
              <i class="fas fa-bars"></i>
            </button>

            @if (auth()->guard('usuario')->check())
              {{-- En mobile ocultamos este item con CSS (.mobile-account) --}}
              <li class="nav-item mobile-account d-flex d-md-none" style="display:flex;align-items:center;">
                <a class="nav-link sin-borde" href="{{ route('web.clientes.logout') }}" style="color:white;width:22px;padding-top:6px;font-size:13px;padding-left:15px;"><span>(Salir)</span></a>
              </li>
            @else
              {{-- En mobile ocultamos este ícono con CSS (.mobile-account) --}}
              <li class="nav-item mobile-account d-flex d-md-none" style="list-style-type:none">
                <a class="nav-link sin-borde" href="{{ route('web.clientes') }}"><img src="{{ asset('img/home/user.svg') }}" alt="Mi cuenta"></a>
              </li>
            @endif

            <li class="nav-item d-flex d-md-none">
              <cart ref="cart" href="{{ route('web.carrito') }}" img="{{ asset('img/home/carrito.jpeg') }}"/>
            </li>

            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog"><div class="modal-content">
                <div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
                <div class="modal-body">
                  <li class="nav-item {{ $breadcrumb[0]['title'] == 'home' ? 'nav-item-active' : '' }}"><a class="nav-link" href="{{ route('web.home') }}">Inicio</a></li>
                  <li class="nav-item {{ $breadcrumb[0]['title'] == 'productos' ? 'nav-item-active' : '' }}"><a class="nav-link" href="{{ route('web.productos.productos2.mobile', $familia_1) }}">Productos</a></li>
                  <li class="nav-item {{ $breadcrumb[0]['title'] == 'videos' ? 'nav-item-active' : '' }}"><a class="nav-link" href="{{ route('web.videos') }}">Videos</a></li>
                </div>
                <div class="modal-footer"></div>
              </div></div>
            </div>

            <div style="display:flex;">
              <ul class="nav d-none d-md-flex">
                <li class="nav-item {{ $breadcrumb[0]['title'] == 'home' ? 'nav-item-active' : '' }}" style="width:89px;"><a class="nav-link" href="{{ route('web.home') }}">Inicio</a></li>
                <li class="nav-item {{ $breadcrumb[0]['title'] == 'productos' ? 'nav-item-active' : '' }}" style="width:115px;"><a class="nav-link" href="{{ route('web.productos.productos2', $familia_1) }}">Productos</a></li>
                <li class="nav-item {{ $breadcrumb[0]['title'] == 'videos' ? 'nav-item-active' : '' }}" style="width:94px;"><a class="nav-link" href="{{ route('web.videos') }}">Videos</a></li>
                <li class="nav-item" style="margin-left:20px;"><cart class="no-hover" ref="cart" href="{{ route('web.carrito') }}" img="{{ asset('img/home/carrito.jpeg') }}"/></li>

                @if (auth()->guard('usuario')->check())
                  <li class="nav-itemr" style="color:white;padding-left:15px;display:flex;align-items:center;">Hola, {{ auth()->guard('usuario')->user()->email }}</li>
                  <li class="nav-item" style="display:flex;align-items:center;"><a class="nav-link sin-borde" href="{{ route('web.clientes.logout') }}" style="width:32px;padding-top:6px;font-size:13px;padding-left:15px;"><span>(Salir)</span></a></li>
                @else
                  <li class="nav-item"><a class="nav-link sin-borde no-hover" style="margin-left:20px;" href="{{ route('web.clientes') }}">MI CUENTA</a></li>
                @endif
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <!-- /HEADER -->

      <main>@yield('content')</main>

      <!-- FOOTER -->
      <footer>
        @if (($breadcrumb[0]['title'] == 'home' ||  $breadcrumb[0]['title'] == 'contacto') && $configuracion->wsp_show)
          <div class="footer-top">
            <a href="https://api.whatsapp.com/send?phone={{ $configuracion->wsp }}" {{ $configuracion->wsp ? 'target=”_blank”' : '' }}>
              <div class="border-wsp"><i class="fab fa-whatsapp"></i></div>
            </a>
          </div>
        @endif

        <div class="footer-info d-none d-md-flex">
          <div class="container footer-box" style="padding-top:0;padding-bottom:0;">
            <div class="row">
              <div class="col-3 d-none d-sm-none d-md-block izquierda" style="padding-top:74px;">
                <img src="{{ asset(Storage::url($home->logo_footer)) }}" style="width:35%;margin-bottom:15px;">
                <p>{{ $home->frase_footer }}</p>
                <div class="footer-redes" style="display:flex;">
                  @foreach ($redes as $red)
                    <a href="{{ $red->url }}" {{ $red->url ? 'target=”_blank”' : '' }}>{!! $red->icono !!}</a>
                  @endforeach
                </div>
              </div>

              <div class="col-9" style="padding-top:74px;">
                <div class="container" style="padding-right:0;">
                  <div class="row">
                    <div class="col-4 d-none d-sm-none d-md-block">
                      <h5>Secciones</h5>
                      <div class="row secciones">
                        <div class="col-6 d-none d-sm-none d-md-block">
                          <p><a href="{{ route('web.home') }}">Inicio</a></p>
                          <p><a href="{{ route('web.productos.productos2', $familia_1) }}">Productos</a></p>
                        </div>
                        <div class="col-6 d-none d-sm-none d-md-block">
                          <p><a href="{{ route('web.videos') }}">Video</a></p>
                        </div>
                      </div>
                    </div>

                    <div class="col">
                      <h5>Suscribite al Newsletter</h5>
                      <form method="POST" action="{{ route('web.email') }}">
                        @csrf
                        <div class="input-box newsletter" style="position:relative;margin-right:15px;justify-content:flex-end;">
                          <input type="text" placeholder="Ingresa tu email" name="email" id="nombreParaVincular">
                          <button type="submit" class="orangeBg"><i class="far fa-paper-plane"></i></button>
                        </div>
                      </form>
                    </div>

                    <div class="col" style="padding-left:0;padding-right:0;">
                      <h5>Contacto</h5>
                      <div class="item-footer"><i class="fas fa-map-marker-alt" style="margin-top:4px;margin-right:5px;"></i><p style="line-height:19px;">{{ $configuracion->direccion }}</p></div>
                      <div class="item-footer"><i class="fas fa-phone-alt"></i><p>{!! $configuracion->tel !!}</p></div>
                      <div class="item-footer"><i class="fas fa-envelope"></i><p><a href="mailto:{{ $configuracion->email }}" target=”_blank”>{{ $configuracion->email }}</a></p></div>
                    </div>

                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </footer>
      <!-- /FOOTER -->

    </div> <!-- /#app -->

    <!-- SCRIPTS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jodit/3.4.25/jodit.min.js"></script>

    @if(!$isFinal)
  <script type="text/javascript" src="{{ asset('js/app.js?v=20251115') }}"></script>
     @endif

    <script>
      document.addEventListener('DOMContentLoaded', function () {
        var base   = document.querySelector('meta[name="public-path"]');
        var PUBLIC = base ? base.content.replace(/\/+$/, '') + '/' : '/';

        function fixUrl(u) {
          if (!u) return u;
          if (/^(https?:)?\/\//i.test(u) || u.startsWith('/')) return u;
          if (u.startsWith('public/'))  return '/storage/' + u.replace(/^public\//, '');
          if (u.startsWith('storage/')) return '/' + u;
          return u;
        }

        document.querySelectorAll('[src], [data-src], [data-lazy], [href]').forEach(function (el) {
          ['src','data-src','data-lazy','href'].forEach(function(attr){
            if (el.hasAttribute(attr)) {
              var v = el.getAttribute(attr);
              var nv = fixUrl(v);
              if (nv && nv !== v) el.setAttribute(attr, nv);
            }
          });
        });

        document.querySelectorAll('img[srcset], source[srcset]').forEach(function (el) {
          var ss = el.getAttribute('srcset');
          if (!ss) return;
          var parts = ss.split(',').map(function (p) {
            var seg = p.trim().split(/\s+/);
            seg[0] = fixUrl(seg[0]);
            return seg.join(' ');
          });
          el.setAttribute('srcset', parts.join(', '));
        });

        document.querySelectorAll('[style*="background"]').forEach(function (el) {
          var bg = el.style.backgroundImage;
          if (!bg) return;
          var m = bg.match(/url\(["']?(.*?)["']?\)/i);
          if (!m) return;
          var fixed = fixUrl(m[1]);
          if (fixed && fixed !== m[1]) el.style.backgroundImage = 'url("'+ fixed +'")';
        });
      });
    </script>

    @if($isCheckout)
    <script>
      (function(){
        // ==== Mata-overlays con “pausa” cuando se hace click en REALIZAR PEDIDO ====
        var ffHoldKillMsUntil = 0;

        function killOverlays(){
          if (Date.now() < ffHoldKillMsUntil) return; // pausa activa
          try{
            document.querySelectorAll(
              '.modal-backdrop, .modal[aria-modal="true"], .sweet-overlay, ' +
              '.swal2-container, .swal2-shown, .vld-overlay, [data-overlay]'
            ).forEach(function(el){ el.remove(); });
            document.body.classList.remove('modal-open','swal2-shown');
            document.body.style.removeProperty('padding-right');
            document.body.style.removeProperty('overflow');
          }catch(e){}
        }

        // Click global: si es el CTA, pausamos la limpieza 4s; si no, limpiamos normal
        window.addEventListener('click', function(e){
          var btn = e.target.closest('button, a, input[type="button"], input[type="submit"]');
          var label = (btn && ((btn.textContent||btn.value)||'').toLowerCase().trim()) || '';
          if (/realizar pedido/.test(label)) {
            ffHoldKillMsUntil = Date.now() + 4000; // 4 segundos de “no tocar overlays”
            setTimeout(killOverlays, 4200);
            return;
          }
          killOverlays();
        }, true);

        document.addEventListener('shown.bs.modal', killOverlays);
        document.addEventListener('show.bs.modal', killOverlays);
        document.addEventListener('hide.bs.modal', killOverlays);
        document.addEventListener('hidden.bs.modal', killOverlays);
      })();
    </script>
    @endif

@if($isCheckout)
<script>
/* ====== Parche de textos/labels sin recompilar Vue + heading ====== */
(function () {
  const desired = {
    dni: 'Ingrese CUIT o DNI', email:'Correo electrónico *', direccion:'Dirección de entrega *', cp:'Código Postal *',
    nombreApe:'Nombre y Apellido *', tel:'Teléfono', entrecalles:'Entre calles / piso / dpto',
    localidad:'Localidad *', provincia:'Provincia *',
    obs:'Notas del pedido / referencias / aclaraciones respecto a la entrega',
    heading:'Solicitamos los siguientes datos para dar curso al pedido'
  };
  const norm = s => (s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();

  function patchPlaceholders(root){
    root.querySelectorAll('input, textarea, label').forEach(function(el){
      const isLabel = el.tagName === 'LABEL';
      const ph  = isLabel ? '' : (el.getAttribute('placeholder') || '');
      const nm  = (el.getAttribute('name') || '');
      const tx  = isLabel ? (el.textContent || '') : ph;
      const t   = norm(tx);
      const nn  = norm(nm);

      if (!isLabel) {
        if (/(dni|cuit)/.test(t) || /(dni|cuit)/.test(nn)) el.setAttribute('placeholder', desired.dni);
        else if (/(email|correo)/.test(t) || el.type === 'email') el.setAttribute('placeholder', desired.email);
        else if (/^direccion\b/.test(t) || /(domicilio|direccion)/.test(nn)) el.setAttribute('placeholder', desired.direccion);
        else if (/(codigo\s*postal|^cp\b)/.test(t) || /(cp|postal)/.test(nn)) el.setAttribute('placeholder', desired.cp);
        else if (/(telefono|celular)/.test(t) || el.type === 'tel') el.setAttribute('placeholder', desired.tel);
        else if (/\bentre\b/.test(t) && /calle/.test(t)) el.setAttribute('placeholder', desired.entrecalles);
        else if (/\blocalidad\b/.test(t) || /localidad/.test(nn)) el.setAttribute('placeholder', desired.localidad);
        else if (/\bprovincia\b/.test(t) || /provincia/.test(nn)) el.setAttribute('placeholder', desired.provincia);
        else if (/(nota|observa)/.test(t) || /(observacion|nota)/.test(nn)) el.setAttribute('placeholder', desired.obs);
        if (/nombre/.test(t) && /apellid/.test(t)) el.setAttribute('placeholder', desired.nombreApe);
      } else {
        if (/(dni|cuit)/.test(t)) el.textContent = 'Documento (DNI o CUIT)';
        else if (/(email|correo)/.test(t)) el.textContent = 'Correo electrónico';
        else if (/^direccion\b/.test(t)) el.textContent = 'Dirección de entrega';
        else if (/(codigo\s*postal|^cp\b)/.test(t)) el.textContent = 'Código Postal';
      }
    });
  }

  function patchHeading(root){
    root.querySelectorAll('.section-carrito h1, .section-carrito h2, .section-carrito h3').forEach(function(h){
      const txt = norm(h.textContent);
      if (txt.includes('orden de compra')) return;
      if (txt.includes('completar los datos') || txt.includes('datos para envio') || txt.includes('datos para envío') || txt.includes('finalizar compra')) {
        h.textContent = desired.heading;
      }
    });
  }

  function patchAll(){ const root=document; patchPlaceholders(root); patchHeading(root); }
  document.addEventListener('DOMContentLoaded', patchAll);
  let tries=0, iv=setInterval(function(){ patchAll(); if(++tries>40) clearInterval(iv); }, 250);
  if('MutationObserver' in window) new MutationObserver(patchAll).observe(document.body,{childList:true,subtree:true});
})();
</script>

<style>
  /* Normalizador tipografía + separadores “Productos” */
  .ff-prodarea, .ff-prodarea * { font-size:14px!important; color:#222!important; font-weight:400!important; text-decoration:none!important; font-family:"Inter","Open Sans",Arial,sans-serif!important; }
  .ff-prodarea [style*="color"] { color:#222!important; }
  .ff-item-start { border-top:1px solid #e5e7eb!important; margin-top:8px!important; padding-top:8px!important; }
  .ff-item-start.ff-first { border-top:none!important; margin-top:0!important; padding-top:0!important; }
</style>
<script>
(function () {
  function txt(el){ return (el && el.textContent || '').trim(); }
  function normalizeProductos() {
    const root = document.querySelector('.section-carrito');
    if (!root) return;
    const prodTitle = Array.from(root.querySelectorAll('*')).find(el => txt(el).toLowerCase() === 'productos:');
    if (!prodTitle) return;

    const stopRx = /^(env[ií]o|retiro|total)\b/i;
    let el = prodTitle.nextElementSibling, rows=[], guard=0;
    while (el && guard++<200) { const t=txt(el); if (stopRx.test(t)) break; if (el.nodeType===1) rows.push(el); el=el.nextElementSibling; }
    rows.forEach(n => n.classList.remove('ff-prodarea','ff-item-start','ff-first'));
    rows.forEach(n => n.classList.add('ff-prodarea'));

    let first=false;
    rows.forEach(n=>{
      const t=txt(n).toLowerCase();
      const isHeader = /\b\d+\s*un\b.*-/.test(t) || /\$\s*[\d.]+(?:,\d+)?/.test(t);
      if (isHeader){ n.classList.add('ff-item-start'); if(!first){ n.classList.add('ff-first'); first=true; } }
    });
  }
  document.addEventListener('DOMContentLoaded', normalizeProductos);
  let tries=0, iv=setInterval(function(){ normalizeProductos(); if(++tries>80) clearInterval(iv); }, 250);
  const target=document.querySelector('.section-carrito')||document.body;
  if(target && 'MutationObserver' in window) new MutationObserver(normalizeProductos).observe(target,{childList:true,subtree:true});
})();
</script>

<!-- === TACHITO (eliminar ítem) - Forzar visible o crear uno propio junto al precio === -->
<style>
  .section-carrito .fa-trash,
  .section-carrito [class*="trash" i],
  .section-carrito [class*="remove" i],
  .section-carrito [class*="eliminar" i]{
    display:inline-block !important;
    visibility:visible !important;
    opacity:1 !important;
  }
  .ff-price-wrap{display:inline-flex;align-items:center;gap:8px;justify-content:flex-end;flex-wrap:nowrap}
  .ff-del{background:none;border:0;cursor:pointer;opacity:.85;padding:0 2px;font-size:16px;line-height:1}
  .ff-del:hover{opacity:1;transform:scale(1.05)}
</style>
<script>
(function(){
  function isHidden(el){
    const cs = getComputedStyle(el);
    return el.offsetParent === null || cs.display === 'none' || cs.visibility === 'hidden' || +cs.opacity === 0;
  }
  const $all = (s,r=document)=>Array.from(r.querySelectorAll(s));

  function ensureTrash(){
    const scope = document.querySelector('.section-carrito') || document;
    if(!scope) return;

    // Filas candidatas: las que tienen input de cantidad
    const qtyInputs = $all('input[type="number"], input[name*="cant"], input[name*="qty"], input[name*="cantidad"]', scope);

    qtyInputs.forEach(inp=>{
      const row = inp.closest('.row, .producto, .product, .item, li, tr, .carrito, .cart, div') || inp.parentElement;
      if(!row || row.dataset.ffTrashOk) return;

      // 1) Localizamos el "eliminar" original (aunque esté oculto)
      let del = row.querySelector('.fa-trash, [class*="trash" i], [class*="remove" i], [class*="eliminar" i], a[href*="eliminar"], a[href*="remove"], button[onclick*="eliminar"], button[onclick*="remove"]');

      // 2) Localizamos el precio para anclar el botón
      let price = row.querySelector('[class*="precio" i], [class*="price" i]');
      if(!price){
        price = $all('*', row).find(n => /\$\s*\d[\d\.\,]*/.test((n.textContent||'').trim()));
      }

      // Si ya hay eliminar visible, marcamos y listo
      if(del && !isHidden(del)){ row.dataset.ffTrashOk='1'; return; }

      // Si no hay ningún candidato, probamos otros botones del row con "eliminar/borrar"
      if(!del){
        del = $all('button, a', row).find(b =>
          /remove|eliminar|borrar/i.test(b.getAttribute('onclick')||'') ||
          /eliminar|remove|borrar/i.test(b.textContent||'')
        );
      }
      if(!del) return; // no tenemos a qué clickear

      // 3) Creamos un botón visible que dispara el "del" original
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'ff-del';
      btn.innerHTML = (document.querySelector('.fa-trash') ? '<i class="fas fa-trash"></i>' : '🗑');
      btn.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); del.click(); });

      // 4) Lo colocamos al lado del precio (o al final del row si no lo encontramos)
      if(price){
        const holder = document.createElement('span');
        holder.className = 'ff-price-wrap';
        price.parentNode.insertBefore(holder, price);
        holder.appendChild(price);
        holder.appendChild(btn);
      } else {
        row.appendChild(btn);
      }

      row.dataset.ffTrashOk='1';
    });
  }

  document.addEventListener('DOMContentLoaded', ensureTrash);
  let tries=0, iv=setInterval(()=>{ ensureTrash(); if(++tries>60) clearInterval(iv); }, 250);
  if('MutationObserver' in window){
    new MutationObserver(ensureTrash).observe(document.body,{childList:true,subtree:true});
  }
})();
</script>
<!-- === /TACHITO === -->

<!-- ===== Checkout failsafe (v2): deja correr el submit original y usa plan B sólo si no pasa nada ===== -->
<script>
(function(){
  const N = s => (s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
  let sending = false;

  // Protegemos el carrito de borrados mientras enviamos
  try{
    const origRemove = localStorage.removeItem.bind(localStorage);
    localStorage.removeItem = function(k){
      if (sending && k === 'cart') return;
      return origRemove(k);
    };
  }catch(e){}

  function qAll(sel){ return Array.from(document.querySelectorAll(sel)); }
  function val(el){ return el ? (el.value||'').trim() : ''; }

  // Saca un resumen de texto del bloque "Productos:" para meter en Notas si usamos fallback
  function gatherProductSummary(){
    const root = document.querySelector('.section-carrito');
    if (!root) return '';
    const title = Array.from(root.querySelectorAll('*'))
      .find(el => (el.textContent||'').trim().toLowerCase() === 'productos:');
    if (!title) return '';

    const stop = /^(env[ií]o|retiro|total)\b/i;
    let el = title.nextElementSibling, lines = [], guard = 0;
    while (el && guard++ < 300) {
      const t = (el.textContent||'').replace(/\s+/g,' ').trim();
      if (t && stop.test(t.toLowerCase())) break;
      if (t) lines.push(t);
      el = el.nextElementSibling;
    }
    return lines.length ? 'Detalle (auto):\n' + lines.join('\n') : '';
  }

  // Adjunta posibles claves de carrito del localStorage (además de stringCart)
  function appendCartParams(P){
    try{
      const keys = Object.keys(localStorage);
      keys.forEach(k=>{
        if (!/cart|carrito|items|productos|detalle/i.test(k)) return;
        const v = localStorage.getItem(k);
        if (v) P.append(k, v);
      });
      const std = localStorage.getItem('cart');
      if (std) P.append('stringCart', std);
    }catch(e){}
  }

  function collectPayload(){
    const P = new URLSearchParams();
    P.append('_token', '{{ csrf_token() }}');

    const nombre     = document.querySelector('[name*="usuario_nombre"], [placeholder*="ombre"][placeholder*="apell"]');
    const dni        = document.querySelector('[name*="usuario_dni"], [name*="cuit"], [placeholder*="cuit"], [placeholder*="dni"]');
    const email      = document.querySelector('[name*="usuario_email"], [type="email"], [placeholder*="correo"]');
    const tel        = document.querySelector('[name*="usuario_celular"], [type="tel"], [placeholder*="tel"]');
    const dom        = document.querySelector('[name*="usuario_domicilio"], [placeholder*="direc"]');
    const loc        = document.querySelector('[name*="usuario_localidad"], [placeholder*="localidad"]');
    const prov       = document.querySelector('[name*="usuario_provincia"], [placeholder*="provincia"]');
    const cp         = document.querySelector('[name*="usuario_cp"], [name*="postal"], [placeholder*="postal"]');
    const obs        = document.querySelector('[name*="observa"], textarea');

    // Campos base
    P.append('usuario_nombre',    val(nombre));
    P.append('usuario_dni',       val(dni));
    P.append('usuario_email',     val(email));
    P.append('usuario_celular',   val(tel));
    P.append('usuario_domicilio', val(dom));
    P.append('usuario_localidad', val(loc));
    P.append('usuario_provincia', val(prov));
    P.append('usuario_cp',        val(cp));

    // Notas / Mensaje (sumamos detalle auto si está vacío)
    let obsTxt = val(obs);
    const auto = gatherProductSummary();
    if (auto) obsTxt = obsTxt ? (obsTxt + '\n\n' + auto) : auto;
    P.append('observacion', obsTxt);

    const envio = document.querySelector('input[name="envio"]:checked');
    const pago  = document.querySelector('input[name="pago"]:checked');
    if (envio) P.append('envio', envio.value||'');
    if (pago)  P.append('pago',  pago.value||'');

    const tHidden = document.querySelector('[name="total"]');
    const eHidden = document.querySelector('[name="envio_calculado"]');
    if (tHidden) P.append('total', tHidden.value||'');
    if (eHidden) P.append('envio_calculado', eHidden.value||'');

    appendCartParams(P);
    return P;
  }

  function submitAsForm(params){
    if (sending) return;
    sending = true;
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '{{ route('web.envio_pedido') }}';
    form.style.display = 'none';
    for (const [k,v] of params.entries()){
      const i = document.createElement('input');
      i.type='hidden'; i.name=k; i.value=v;
      form.appendChild(i);
    }
    document.body.appendChild(form);
    form.submit();
  }

  function sendWithFetch(){
    if (sending) return;
    sending = true;
    const params = collectPayload();

    fetch('{{ route('web.envio_pedido') }}', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: params.toString()
    })
    .then(async r => {
      const ct = r.headers.get('content-type')||'';
      if (ct.includes('application/json')) return r.json();
      const t = await r.text(); try { return JSON.parse(t); } catch { return { status:'raw', html:t }; }
    })
    .then(j => {
      if (j && (j.redirect || j.url)) {
        window.location.href = j.redirect || j.url;
      } else {
        submitAsForm(params); // si la API devolvió HTML/JSON raro, caemos al form clásico
      }
    })
    .catch(() => submitAsForm(params));
  }

  function isCTA(el){
    if (!el) return false;
    const btn = el.closest('button, a, input[type="submit"], input[type="button"]');
    if (!btn) return false;
    const t = N(btn.textContent || btn.value || '');
    return t.includes('realizar') && t.includes('pedido');
  }

  // >>> YA NO INTERCEPTAMOS submit del form: dejamos que corra el original
  // Usamos fallback sólo si, tras hacer click, no ocurrió navegación

  function planBConTimeout(ms){
    const hrefBefore = location.href;
    setTimeout(function(){
      if (location.href !== hrefBefore) return; // el flujo original navegó OK
      sendWithFetch();                          // si no pasó nada, usamos fallback
    }, ms);
  }

  // Click en CTA
  document.addEventListener('click', function(ev){
    if (!isCTA(ev.target)) return;
    // no prevenimos el default: damos tiempo al handler original
    planBConTimeout(1200);
  }, true);

  // Enter dentro del bloque checkout: intentamos submit nativo; si no navega, fallback
  document.addEventListener('keydown', function(ev){
    if (ev.key !== 'Enter') return;
    const scope = document.querySelector('.section-carrito');
    if (!scope || !scope.contains(ev.target)) return;

    const form = document.getElementById('formFinal') || scope.querySelector('form');
    if (form && form.requestSubmit) form.requestSubmit();
    else {
      const cta = qAll('button,a,input').find(isCTA);
      if (cta) cta.click();
    }
    ev.preventDefault();
    planBConTimeout(1200);
  }, true);
})();
</script>

@endif

    @yield('scripts')
  </body>
</html>
