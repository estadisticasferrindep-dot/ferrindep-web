@extends('layouts.app')

@section('title','Pedidos')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">

            @if (session('status'))
                <div class="alert alert-success" role="alert">
                    {{ session('status') }}
                </div>
            @endif

            <br><br>

            <div class="card" style="margin-top:15px;">
                <div class="card-body p-0">

                    {{-- Tabla con id explícito --}}
                    <table id="pedidos-table" class="table">
                        <thead style="color:#03224e">
                            <tr>
                                <th scope="col">Fecha</th>
                                <th scope="col">Código</th> {{-- NUEVO --}}
                                <th scope="col">Cliente</th>
                                <th scope="col">Total</th>
                                <th scope="col">Detalle</th>
                                <th scope="col">Medio de pago</th>
                                <th scope="col">Envío</th>
                                <th scope="col">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($pedidos as $pedido)
                                @php
                                    // Elegí el campo real de tu código de pedido aquí si ya existe.
                                    // Fallbacks: codigo | order_code | numero | uuid | "FD-000123" a partir de id.
                                    $codigoPedido = $pedido->codigo
                                        ?? $pedido->order_code
                                        ?? $pedido->numero
                                        ?? $pedido->uuid
                                        ?? ('FD-' . str_pad((string)($pedido->id ?? 0), 6, '0', STR_PAD_LEFT));
                                @endphp
                                <tr>
                                    <td>{{ optional($pedido->created_at)->format('Y-m-d H:i:s') }}</td>
                                    <td style="white-space:nowrap; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, 'Liberation Mono', monospace;">
                                        {{ $codigoPedido }}
                                    </td> {{-- NUEVO --}}
                                    <td>{{ $pedido->usuario_nombre }}</td>
                                    <td>${{ number_format((float)$pedido->total, 0, ',', '.') }}</td>
                                    <td>
                                        @if (!empty($pedido->itemsPedidos))
                                            <ol class="mb-0">
                                                @foreach ($pedido->itemsPedidos as $item)
                                                    @if($item->con_nombre)
                                                        <li style="list-style:none;">
                                                            <strong>{{ $item->cantidad }}X</strong>
                                                            {{ $item->nombre }}
                                                            @if($item->ancho !== null && $item->ancho !== '')
                                                                ({{ $item->ancho }})
                                                            @endif
                                                        </li>
                                                    @else
                                                        <li style="list-style:none;">
                                                            <strong>{{ $item->cantidad }}X</strong>
                                                            {{ $item->medidas }} {{ $item->espesor }}
                                                            {{ (intval($item->nombre) >= 100 ? $item->nombre/100 . ' m alto/ancho' : $item->nombre . ' cm alto/ancho') }}
                                                            @if($item->ancho !== null && $item->ancho !== '')
                                                                — Ancho: {{ $item->ancho }}
                                                            @endif
                                                            ({{ $item->metros }}m)
                                                        </li>
                                                    @endif
                                                @endforeach
                                            </ol>
                                        @endif
                                    </td>
                                    <td style="text-transform: uppercase">{{ $pedido->pago }}</td>
                                    <td style="text-transform: uppercase">{{ $pedido->envio }}</td>
                                    <td>
                                        <div style="display:flex; align-items:center">
                                            <button type="button" class="btn btn-primary" style="margin-right:5px;">
                                                <a style="color:white;" href="{{ route('pedidos.edit',$pedido) }}">
                                                    <i class="far fa-eye"></i>
                                                </a>
                                            </button>
                                            <form action="{{ route('pedidos.destroy', $pedido) }}" method="POST">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" onclick="return confirm('¿Estas seguro?');" class="btn btn-danger">
                                                    <a style="color:white;" href="#"><i class="fas fa-trash-alt"></i></a>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="8" class="text-center py-4">No hay pedidos para mostrar.</td>
                                </tr>
                            @endforelse
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="8">
                                    @if(method_exists($pedidos, 'links'))
                                        <div class="px-3 pb-3">
                                            {{ $pedidos->links() }}
                                        </div>
                                    @endif
                                </td>
                            </tr>
                        </tfoot>
                    </table>

                </div>
            </div>

        </div>
    </div>
</div>

{{-- ===== Anti-DataTables (v1 y v2): oculta/borra wrappers y destruye instancias ===== --}}
<style>
/* Ocultar UI de DataTables v1 */
.dataTables_wrapper,
.dataTables_length,
.dataTables_filter,
.dataTables_info,
.dataTables_paginate { display: none !important; }
/* Ocultar UI de DataTables v2 */
.dt-container,
.dt-length,
.dt-search,
.dt-info,
.dt-paging,
.dt-processing,
.dt-scroll { display: none !important; }
</style>

<script>
(function() {
  function nukeDT() {
    var table = document.getElementById('pedidos-table');
    if (!table) return;

    // --- jQuery DataTables (v1) ---
    if (window.jQuery && (jQuery.fn.DataTable || jQuery.fn.dataTable)) {
      var $t = jQuery('#pedidos-table');
      try {
        var isV1 = (jQuery.fn.DataTable && jQuery.fn.DataTable.isDataTable && jQuery.fn.DataTable.isDataTable($t))
                 || (jQuery.fn.dataTable && jQuery.fn.dataTable.isDataTable && jQuery.fn.dataTable.isDataTable($t));
        if (isV1) {
          try { $t.DataTable().destroy(); } catch(e) { try { $t.dataTable().fnDestroy(); } catch(e2){} }
        }
      } catch (e) {}
    }

    // --- DataTables v2 (vanilla) no-jQuery: des-envolver si existe ---
    var wrapV2 = table.closest ? table.closest('.dt-container') : null;
    if (wrapV2) {
      wrapV2.parentNode.insertBefore(table, wrapV2);
      wrapV2.remove();
    }

    // --- DataTables v1 wrapper ---
    var wrapV1 = table.closest ? table.closest('.dataTables_wrapper') : null;
    if (wrapV1) {
      wrapV1.parentNode.insertBefore(table, wrapV1);
      wrapV1.remove();
    }

    // Limpieza de restos
    table.classList.remove('dataTable','dt-table');
    document.querySelectorAll('.dataTables_wrapper, .dt-container').forEach(function(w){ w.remove(); });
  }

  // Ejecutar y reintentar (por si se inicializa tarde)
  document.addEventListener('DOMContentLoaded', function () {
    nukeDT();
    setTimeout(nukeDT, 80);
    setTimeout(nukeDT, 250);
    setTimeout(nukeDT, 800);
    setTimeout(nukeDT, 1500);
  });

  // Vigilar inyecciones futuras de wrappers
  var obs = new MutationObserver(function(muts) {
    var hit = muts.some(m => Array.from(m.addedNodes||[]).some(n =>
      n.nodeType===1 && (n.classList.contains('dataTables_wrapper') || n.classList.contains('dt-container'))
    ));
    if (hit) nukeDT();
  });
  obs.observe(document.body, { childList: true, subtree: true });
})();
</script>

@endsection
