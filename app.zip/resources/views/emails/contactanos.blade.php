<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
    <p>Nombre: {{$info['nombre']}}</p>
    <p>Apellido: {{$info['apellido']}}</p>
    <p>Celular: {{$info['celular']}}</p>
    <p>Email: {{$info['email']}}</p>

    <p>Mensaje: </p>
    <p>{{$info['mensaje']}}</p>
</body>
</html>