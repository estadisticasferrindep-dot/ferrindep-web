<template>

    <div >
            <div v-if="presentaciones2.length >= 1">
                <p v-if="desde > 0 " class="precio" style="text-align: left; font: normal normal bold 25px/34px Open Sans;
                letter-spacing: 0px;
                color: #FD914D;
                margin-bottom:0">
                        <span v-if="parseFloat(oferta)" class="precio-oferta">
                            ${{desdeOferta}} - $ {{hastaOferta}} <span v-if="conNombre  != 1"> x mt </span>
                        </span>
                        $ {{desde}} - $ {{hasta}} <span v-if="conNombre  != 1"> x mt </span>
                    </p>
                <p  v-else class="precio" style="text-align: left; font: normal normal bold 25px/34px Open Sans;
                letter-spacing: 0px;
                color: #FD914D;
                margin-bottom:0">
                        <span style="font: normal normal bold 15px/20px Open Sans;">Consultar precio</span>
                        
                    </p>
            </div>

            <div class="tabla-trabajo" style="font: normal normal normal 14px/19px Open Sans;
            letter-spacing: 0px;
            color: #939292;
            margin-top: 3px;">
                {{vendidos}} vendidos
            </div>

        <hr class="subtitulos">


        <div v-html="descripcion" style="font: normal normal normal 15px/20px Open Sans;
        color: #333333;">

        </div>

        <div v-if="presentaciones2.length >= 1">

            <table>
                <thead>
                    <tr>
                        <td class="d-none d-md-flex">Presentación</td>
                        <td class="d-flex d-md-none" style="padding-right: 13px;">Longitud</td>

                        <td>Precio</td>
                        <td>Unidades</td>
                        <td style="text-align:right; width:115px">Total</td>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(presentacion, key) in presentaciones2" :key="key">
                        <td v-if="presentacion.show">{{presentacion.nombre}}
                            <div v-if="presentacion.free" style="color:green; font-weight:bold; font-size: 13px;">(Envío gratis)</div>
                        </td>
                        <td v-if="presentacion.show">
                            <div v-if="parseFloat(presentacion.precio) <= 0 ">
                                Consultar precio
                            </div>

                            <div v-if="parseFloat(presentacion.precio) > 0 "><span v-if="parseFloat(oferta)" class="d-flex d-md-none" style="text-decoration: line-through;
                            color: #999999;
                            margin-right: 12px;">
                                ${{presentacion.precio_anterior }}</span>${{presentacion.precio }} 
                            </div>
                            <div v-if="presentacion.metros > 1 && parseFloat(presentacion.precio) > 0 && presentacion.medidas == null" style="font: normal normal normal 12px/17px Open Sans;">
                                ({{Math.round(presentacion.precio / presentacion.metros)}} x m)
                            </div>
                            <div v-if="presentacion.medidas != null" style="font: normal normal normal 12px/17px Open Sans;">
                                ({{presentacion.medidas}})
                            </div>
                        </td>
                        <td v-if="presentacion.show">
                            <!-- <input   v-if="parseFloat(presentacion.precio) <= 0 " disabled id='cant-input' class="input-producto cantidad" type="number" v-model="cantidades[presentacion.id] " :max="Math.min(Math.floor(presentacion.limite),presentacion.stock)" :min="0" :step="1" placeholder="0"> -->
<div  v-if="((parseFloat(presentacion.precio) <= 0) || (presentacion.stock <= 0 ))" style="    text-align: center;">No disponible</div>
<div  v-else-if="(presentacion.stock == 1 )" style="    text-align: center;">
    <div>
    <input  id='cant-input' class="input-producto cantidad" type="number" v-model="cantidades[presentacion.id] " :max="Math.min(Math.floor(presentacion.limite),presentacion.stock)" :min="0" :step="1" placeholder="0">
<div style="font-size: 13px;"> (Último disponible)</div>
    </div>
</div>
                            <input v-else id='cant-input' class="input-producto cantidad" type="number" v-model="cantidades[presentacion.id] " :max="Math.min(Math.floor(presentacion.limite),presentacion.stock)" :min="0" :step="1" placeholder="0">

                            <!-- <input  :id="'cant-input-'presentacion.id" class="input-producto cantidad" type="number" placeholder="Cantidad" :min="0" :step="1" v-model="cantidad"> -->

                        </td> 
                        <td style="text-align:right" v-if="presentacion.show && cantidades[presentacion.id]>0">
                            $ {{cantidades[presentacion.id]>0 ?  presentacion.precio *cantidades[presentacion.id] : ''}} 
                            <div  style="font: normal normal normal 12px/17px Open Sans;">
                            </div>
                        </td>
                    </tr>

                    <!-- <tr >
                        <td></td>
                        <td style="text-align:center;">
                            
                        </td>
                        <td>
                            
                        </td> 
                        <td v-if="total > 0" style="font: normal normal bold 18px/24px Open Sans;
                        letter-spacing: 0px;
                        color: #333333;">
                            $ {{total | toCurrency}} 
                        </td>
                    </tr> -->

                </tbody>

            </table>
        </div> 

        <div v-if="total > 0" style="font: normal normal bold 18px/24px Open Sans;
                        letter-spacing: 0px;
                        color: #333333; display: flex; justify-content: flex-end;">
                            $ {{total | toCurrency}} 
        </div>
        <div style="display: flex; justify-content: flex-end;">

            <!-- <input  id="cant-input" class="input-producto cantidad" type="number" placeholder="Cantidad" :min="1" :step="1" v-model="cantidad"> -->
            
            <button  @click="add" 
                class="btn-comprar" > 
                    AGREGAR A LA ORDEN DE COMPRA
            </button>
        </div>
    </div>
</template>

<script>
    import Swal from 'sweetalert2';
    export default {
        name: 'AddToCartButton',
        props: {  // lo que recibo de FUERA del componente
            id: {type: Number},
            imagen: {type: String},
            oferta: {type: Boolean},
            medidas:{type: String},
            espesor: {type: String},
            descripcion: {type: String},
            presentaciones: {},
            ancho:{type: String},
            ruta: '',
            vendidos:{type: Number},
            anulaEnvio:{type: Boolean},
            familia: {type: String},
            conNombre: {type: Number}
        },
        data() { // lo que tengo de mi componente, sus datos, tambien las globales con window
            return {
                cantidad: 1,
                presentaciones2: {},
                price:0,
                desde: 0, 
                desdeOferta: 0,
                cantidades:{},
                total: 0,
                hasta:0,
                hastaOferta:0,
                cart: []
            };
        },
        watch:{
            cantidades: {
                handler(val){
                    this.redondear_cantidades()
                    this.validacionCantidad()
                    this.calculo_total()
                },
                deep: true
            }
        },
        created() { // lo que aparece cuando se crea el componente
            this.cantidad = 1
            console.log(998)
            console.log(this.familia)
            console.log(999)


            this.presentaciones2 = JSON.parse(this.presentaciones)
            this.desdeCalcular()
console.log(this.presentaciones)
        },
        methods: {
            redondear_cantidades(){

                for (let index = 0; index < this.presentaciones2.length; index++) {
                    let presentacion = this.presentaciones2[index]

                    if (this.cantidades[presentacion.id] > 0) {
                        this.cantidades[presentacion.id] = Math.round(this.cantidades[presentacion.id])
                        
                    }
                    
                }
            },
            validacionCantidad(){
                let cart = JSON.parse(localStorage.getItem('cartQunuy'));

                if(!cart){
                    cart = []
                }
 

                for (let index = 0; index < this.presentaciones2.length; index++) {
                    let item 
                    let lim
                    let presentacion = this.presentaciones2[index]

                    item = cart.find(item=> item.id == this.id && item.presentacionId == presentacion.id)

                    
                    if(item){
                        lim = Math.min(presentacion.limite,presentacion.stock - item.cantidad)
                    }else{
                        lim = Math.min(presentacion.limite,presentacion.stock )
                    }

                    if (this.cantidades[presentacion.id] > lim ) {
                        this.cantidades[presentacion.id] = lim
                    }
                }
            },
            calculo_total(){
                let tot = 0

                for (let index = 0; index < this.presentaciones2.length; index++) {
                console.log( this.presentaciones2.length)

                    tot += this.presentaciones2[index].precio * (this.cantidades[this.presentaciones2[index].id] ? this.cantidades[this.presentaciones2[index].id] : 0 ) 
                    
                }

                this.total = tot
                
            },
            desdeCalcular(){
if(this.conNombre == 1){
                    let preciosXMetro  = this.presentaciones2.map(function(p) {
                        return p.precio;
                    });
                    this.desde = Math.min.apply(null, preciosXMetro)
                    this.hasta = Math.max.apply(null, preciosXMetro)


                    let preciosXMetroOferta  = this.presentaciones2.map(function(p) {
                        return p.precio_anterior;
                    });
                    this.desdeOferta = Math.min.apply(null, preciosXMetroOferta)
                    this.hastaOferta = Math.max.apply(null, preciosXMetroOferta)

                }
                else{
                    let preciosXMetro  = this.presentaciones2.map(function(p) {
                        return Math.round((p.precio)/p.metros);
                    });
                    this.desde = Math.min.apply(null, preciosXMetro)
                    this.hasta = Math.max.apply(null, preciosXMetro)


                    let preciosXMetroOferta  = this.presentaciones2.map(function(p) {
                        return Math.round((p.precio_anterior)/p.metros);
                    });
                    this.desdeOferta = Math.min.apply(null, preciosXMetroOferta)
                    this.hastaOferta = Math.max.apply(null, preciosXMetroOferta)

                }
            },
            add(){

                if(this.total>0){
                    let cart = JSON.parse(localStorage.getItem('cartQunuy'));
                if(!cart){
                    cart = []
                }

                for (let index = 0; index < this.presentaciones2.length; index++) {
                    
                    let presentacion = this.presentaciones2[index]
console.log(presentacion)
                    let item = cart.find(item=> item.id == this.id && item.presentacionId == presentacion.id)

                    if (this.cantidades[presentacion.id] > 0) {
                        if(item){
                            item.cantidad = parseInt(this.cantidades[presentacion.id]) + parseInt(item.cantidad) 
                        }
                        else{
console.log('add'+ this.anulaEnvio)

                            cart.push({ 
                                id: this.id,
                                medidas: this.medidas,
                                espesor: this.espesor,
                                precio: presentacion.precio,
                                presentacionId: presentacion.id,
                                cantidad: this.cantidades[presentacion.id],
                                free: presentacion.free,
                                stock: presentacion.stock,
                                peso: presentacion.peso,
                                limite: presentacion.limite,
                                nombre: presentacion.nombre,
                                metros: presentacion.metros,
                                ancho: this.ancho,
                                descripcion:this.descripcion,
                                imagen: this.imagen,
                                anulaEnvio: this.anulaEnvio,
                                familia: this.familia
                            })
                        }
                    }
                }

                localStorage.setItem("cartQunuy",JSON.stringify(cart));


                this.validacionCantidad()
               

                // Swal.fire(
                // 'Buen trabajo!',
                // 'Se añadió el producto al carrito',
                // 'success'
                // )   

                this.$root.$refs.cart.count();

                window.location = this.ruta
                }
                else{
                    Swal.fire(
                    'Cuidado!',
                    'No se ha indicado ninguna cantidad',
                    'warning'
                    )  
                }
            },
            formatPrice(value) {
                let val = (value/1).toFixed(2).replace('.', ',')
                return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
            }
        },

        
    };
</script>

<style scoped>

    table{
        width: 100%;
        margin-top:30px;
    }

    table thead{
        font: normal normal 600 16px/22px Open Sans;
        color: #333333;
    }

    table tbody{
        font: normal normal normal 16px/22px Open Sans;
        color: #333333;
    }

    table td{
        padding-top:13px;
        padding-bottom:13px;
    }
        table tbody tr{
        border-top: 1px solid rgba(51, 51, 51, 0.15);
        border-bottom: 1px solid rgba(51, 51, 51, 0.15);
    }

    .presentacion {
        border: 1px solid #A6CE39;
        border-radius: 4px;
        font: normal normal 300 15px/18px Open Sans;
        letter-spacing: 0px;
        color: #A6CE39;
        margin-right: 3;
        padding: 3 0 3 0;
        cursor:pointer;
        text-align: center;
        width:23.5%;
        margin-bottom:5px;
        width:35.5%;
    }


    .presentacion:hover, .presentacion.select{
        background: #A6CE39 0% 0% no-repeat padding-box;
        border: 1px solid #A6CE39;
        color: #FFFFFF;
    }

    .subtitulos{
        font: normal normal normal 16px/21px Open Sans;
        font-weight: 500;
        letter-spacing: 0px;
        color: #505050;
    }

    .btn-comprar {
        background: rgba(253, 145, 77, 1) 0% 0% no-repeat padding-box;
        border: 1px solid rgba(253, 145, 77, 1);
        border-radius: 8px;
        text-align: center;
        font: normal normal bold 14px/17px Open Sans;
        letter-spacing: 0.56px;
        color: #FFFFFF;
        text-transform: uppercase;

        margin-top: 20px;
        padding: 12px 0;
        padding-left: 55px;
        padding-right: 55px;
        border:none;
    }


    .input-producto{
        border:none;
        text-align: left;
        padding-left:15px;
        margin-right:14px;
        margin-top: 20px;
        background: #F8F8F8 0% 0% no-repeat padding-box;
        border-radius: 8px;
        margin: 0;
        font: normal normal normal 18px/24px Open Sans;
        letter-spacing: 0px;
        color: #333333;
    }

    .box-clase-mini{
        margin-top:22px;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        max-width: 95%;
        max-height: 95%;
        
        margin-right: calc(var(--bs-gutter-x)/ 2);
        margin-left: calc(var(--bs-gutter-x)/ 2);
        padding: 0;
    }

    .box-clase-mini .overlay{
        padding-bottom: 100%;
    }

    .box-clase-mini .overlay:hover{
        box-shadow: 0 0 0 9px #E9E9E9;
    }


    @media screen and (max-width: 800px) {
        .cantidad{
            width: 44px;
        }

        .btn-comprar{
            padding-left: 40px;
            padding-right: 40px;
        }
    } 








    .add-to-cart-button {
        display: inline-block;
        padding: 0.4em 1em;
        border: none;
        font: inherit;
        font-size: 15px;
        text-transform: uppercase;
        color: #fff;
        background-color: #2f6410;
        cursor: pointer;
        transition: opacity 200ms ease;
    }
    .checkout-button {
        display: inline-block;
        padding: 0.4em 1em;
        border: none;
        font: inherit;
        font-size: 15px;
        text-transform: uppercase;
        border-top-right-radius: 25px;
        border-bottom-right-radius: 25px;
        color: #fff;
        background-color: #111282;
        cursor: pointer;
        transition: opacity 200ms ease;
    }

    .add-to-cart-button:hover {
        opacity: 0.75;
    }
</style>