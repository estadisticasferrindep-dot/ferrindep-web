import anime from 'animejs';
<template>
<div>
    <div class="mt-10-mobile" style="margin-top:87px; margin-bottom: 104px;border: 0.5px solid rgba(143, 134, 110, 0.3);">
            <div >
                <div class="d-none d-md-flex" style=" margin-bottom:0; border: 0.5px solid rgba(143, 134, 110, 0.3); padding:12px 22px 10px 22px;">
                    <!-- <img src="{{ asset('img/carrito/camioneta.svg')}}" style="margin-right: 19px;">  -->
                    <h3 style="color:transparent">.  </h3>
                </div>
    
                <div class="section-envio" >

                    <div class="fila">
                        <h4>Subtotal</h4>
                        <span class="precio" style="text-align: right;">$ {{subtotal | toCurrency}}</span>
                    </div>

                    <hr>

                    <!-- <h4 style="margin-bottom:13px">Envío</h4> -->


                    <div class="fila">
                        <div class="d-flex">
                            <input type="radio" class="me-1" id="caba" v-if="anulaEnvio" disabled name="envio" value="caba" v-model="envio" >
                            <input type="radio" class="me-1" id="caba" v-else name="envio" value="caba" v-model="envio" >
                            
                            <label for="caba">Envío a domicilio</label>
                        </div>
                        <!-- <span v-if="cp=='Código Postal'" style="font: normal normal bold 14px/19px Open Sans; margin-left:15px;">CALCULAR</span>  -->
                        <span v-if="costoEnvioCaba.envioCaba==0 && cp!='Código Postal' && yaCalculo == 1" style="font: normal normal bold 14px/19px Open Sans; margin-left:15px;">FUERA DE RANGO</span> 
                        <span v-if="cp!='Código Postal' && costoEnvioCaba.envioCaba!=0 && costoEnvioCaba.envioCaba!=-1" style="font-weight: 500px; margin-left:15px;">$ {{costoEnvioCaba.envioCaba }}</span> 
                        <span v-if="cp!='Código Postal' && costoEnvioCaba.envioCaba==-1" style="font-weight: 500px; margin-left:15px;">Gratis</span> 
                    </div>
                    <correo-argetino-box
                        v-if="envio=='caba'"
                        @shipping-cost="calcularEnvio"
                         @destino_id="calcularLocalidad"
                    ></correo-argetino-box>



                    <div class="fila">
                        <div class="d-flex">
                            <input type="radio" id="fabrica" name="envio" value="fabrica" v-model="envio" class="me-1">
                            <label for="fabrica">Retiro por depósito  </label>  
                        </div>
                        <span  v-if=" costoEnvioFabrica!='0'" style="font-weight: 500px; margin-left:15px;">$ {{ costoEnvioFabrica}}</span> <span v-else ></span>
                    </div>
                    <div>
                        <p v-if="envio=='fabrica'" v-html="parrafoEnvioFabrica"></p>
                    </div>
                    
                    <!--
                    <p v-if="envio=='caba'" v-html="parrafoEnvioCaba">  </p>
                    <div v-if="envio=='caba'" class="fila">
                        <div>
                            <input class="cp" type="number" id="caba" name="cp" v-model="cp" placeholder="Código Postal" >
                        </div>
                        <span class="d-none d-md-flex" style="font: normal normal bold 14px/19px Open Sans; margin-left:15px;cursor:pointer;" @click="codigoPostal" >ACTUALIZAR</span> 
                    </div>
                    -->
                            <!-- <span class="d-flex d-md-none" style="font: normal normal bold 14px/19px Open Sans; margin-left:15px;cursor:pointer;" @click="codigoPostal" >ACTUALIZAR</span>  -->

                            <!-- <div class="fila"> 
                                <div>
                                    <input type="radio" id="interior" name="envio" value="interior" v-model="envio" >
                                    <label for="interior">Envios al interior</label> 
                                </div>
                                <span  v-if="costoEnvioInterior!='0'" style="font-weight: 500px; margin-left:15px;">$ {{costoEnvioInterior}}</span> <span v-else >Gratis</span>
                            </div>

                            <p v-if="envio=='interior'" v-html="parrafoEnvioInterior">  </p>
 -->

                            <!-- <div class="fila"> 
                                <div>
                                    <input v-if="costoEnvioExpreso< total" type="radio" id="expreso" name="envio" value="expreso" v-model="envio" >
                                    <input v-else disabled type="radio" id="expreso" name="envio" value="expreso" v-model="envio" >
                                    
                                    <label for="expreso">Envío Gratuito</label> 
                                </div>
                                <span style="font: normal normal bold 14px/19px Open Sans; margin-left:15px;"> MINIMO $ {{costoEnvioExpreso | toCurrency}}</span>
                            </div>

                            <p v-if="envio=='expreso'" v-html="parrafoEnvioExpreso">  </p>
                            <hr> -->


                            <div class="fila" style="padding-bottom:6px; padding-top:6px;"> 
                                <p class="total" style="margin:0">Total</p>
                                <span class="precio" style="text-align: right;">$ {{ total  | toCurrency}}</span>
                            </div>
                            <hr>
                            <button @click="productos" style="margin-bottom:10px;">AGREGAR MÁS PRODUCTOS</button>
                            
                            <button @click="finalizar" >CONTINUAR COMPRA</button>

                    </div> 
                    

                    
                </div>

        </div> 


</div>
    
</template>
<script>
    import Swal from 'sweetalert2';
    import correoArgetinoBox from './correo-argetino-box.vue';
    export default {

        props:{
            rutaProductos:'',
            envios:{},
            login:{},


            destinos:{},
            zonas:{},
            destinozonas:{},
            pesozonas:{},


            target: '',
            // parrafoTarjeta: {type: Number},
            // parrafoTransferencia: {type: Number},
            // parrafoLocal: {type: Number},
            // descuentoTarjeta: {type: Number},
            // descuentoTransferencia: {type: Number},
            // descuentoLocal: {type: Number},


            parrafoEnvioFabrica: {type:String},
            parrafoEnvioInterior: {type:String},
            parrafoEnvioCaba: {type:String},
            parrafoEnvioExpreso: {type:String},
            costoEnvioFabrica: {type: Number},
            costoEnvioInterior: {type: Number},
            costoEnvioCaba: {},
            costoEnvioExpreso: {type: Number},

            step: {},
            subtotal:{},
            total:{},
            envio2:{}
        },
        components:{
            correoArgetinoBox
        },
        data() {
            return {
                finalizarcompra: 0,
                envio:'caba',
                pago: 'tarjeta',
                // calles: '',
                // direccion_entrega: '',
                // localidad: '',
                // barrio: '',
                // telefono: '',
                // cp: '',
                // direccion_expreso: '',
                // telefono_expreso: '',
                // nombre_expreso: '',
                cart: [],
                precios: [],
                // iva:0,
                descuento_total: 0,
                envio_total: 0,
                envios2:[],
                destinos2:{},
                zonas2:{},
                destinozonas2:{},
                pesozonas2:{},
                cp:"Código Postal",
                yaCalculo: 0,
                anulaEnvio:0,
                cantidadItems:0,
                shippingCost:null,
                destinoId:0,

            }
        },
        watch:{
            shippingCost: {
                handler(val){
                    this.calculo_envio()
                    this.calculo_total()
                },
                deep: true
            },
            envio: {
                handler(val){
                    this.calculo_envio()
                    this.calculo_total()
                },
                deep: true
            },
            subtotal:{
                handler(val){
                    this.calculo_envio()
                    this.calculo_total()
                },
                deep: true
            },
            total:{
                handler(val){
                    this.cart = JSON.parse(localStorage.getItem('cartQunuy'));
                    this.cantidad()
                    this.codigoPostal()
                },
                deep: true
            }
        },
        mounted() {
            this.$root.$on('seAnulaEnvio', data => {
                this.seAnulaEnvio();
            });
        },
        created() {
            this.cart = JSON.parse(localStorage.getItem('cartQunuy'));
            this.cantidad()
            this.seAnulaEnvio()
            this.costoEnvioCaba.envioCaba=0
            this.calculo_subtotal()

            this.calculo_envio()

            this.calculo_total()
            this.envios2= JSON.parse(this.envios);

            this.destinos2= JSON.parse(this.destinos);
            this.zonas2= JSON.parse(this.zonas);
            this.destinozonas2= JSON.parse(this.destinozonas);
            this.pesozonas2= JSON.parse(this.pesozonas);


        },
        methods: {
            calcularEnvio(total){
                this.shippingCost = total
            },
            calcularLocalidad(destino_id){
                this.destinoId = destino_id
            },
            cantidad(){
                let cantidadTotal = 0;
                for (let index = 0; index < this.cart.length; index++) {
                    cantidadTotal += parseInt(this.cart[index].cantidad) 
                }
                
                this.cantidadItems = cantidadTotal
                this.calculo_envio()
                this.calculo_total()
            },
            seAnulaEnvio(){
                console.log('carrito:')
                console.log( this.cart)
                for (let index = 0; index < this.cart.length; index++) {
                    if (this.cart[index].anulaEnvio == "1") {
                console.log('item que anula:'+ index)

                        this.anulaEnvio = true
                        this.envio= 'fabrica'
                        break
                    }
                    else{
                        this.anulaEnvio = false
                    }
                }
                
                
            },
            productos(){
                window.location.href = this.rutaProductos
            },
            codigoPostal(){
                this.cantidad()
                for (let index = 0; index < this.envios2.length; index++) {

                    if (parseInt(this.envios2[index].cp) == parseInt(this.cp)) {
                        console.log(this.cantidadItems)
                        console.log(parseInt(this.envios2[index].costo))

                        this.costoEnvioCaba.envioCaba = (parseInt(this.envios2[index].costo) * this.cantidadItems)
                        console.log(this.cantidadItems)
                        console.log(this.costoEnvioCaba.envioCaba)

                        break
                    } else {
                        if(this.envios2.length == index + 1){
                        this.costoEnvioCaba.envioCaba = 0

                        }
                    }
                    
                }
                
                this.yaCalculo = 1
                this.calculo_envio()
                this.calculo_total()
            },
            calculo_subtotal(){
                this.subtotal = 0
                this.cart = JSON.parse(localStorage.getItem('cartQunuy'));
                
                this.precios = []
                this.cart.forEach((item) => {
                                this.precios.push(item.price * item.quantity);
                            });
                
                for (var i = 0; i < this.precios.length; i++){			
                    this.subtotal = this.subtotal + this.precios[i];
                }
            },
            calculo_envio(){

                if(this.envio == 'fabrica'){
                    this.envio_total = this.costoEnvioFabrica
                }else{
                    if(this.envio == 'interior'){
                        this.envio_total = this.costoEnvioInterior
                    }else{
                        if(this.envio == 'caba'){
                        this.envio_total =this.shippingCost
                        console.log(this.envio_total);
                        }else{

                            if(this.costoEnvioExpreso > this.subtotal){
                                this.envio = 'fabrica'
                            }else{
                                this.envio_total = 0
                            }
                        }
                    }
                }
                

            },

            // calculo_iva(){
            //     this.iva = this.subtotal * 0.21
            // },
            calculo_total(){

                
                let total = parseInt(this.subtotal) + (parseInt(this.envio_total) == -1 ? 0 : parseInt(this.envio_total) )
                // this.total = this.subtotal - this.descuento_total
                this.$emit('update:destinoId',this.destinoId) 

                this.$emit('update:costoEnvio',this.envio_total) 
                this.$emit('update:total',total)    
            },
            // actualizar_subtotal(cartActualizado){
                
            //     // this.calculo_iva()
            //     // this.calculo_descuento_pago()
            //     this.calculo_envio()
            //     this.calculo_total()
            // },

            finalizar(){ 

                if(this.login != 1 ){
                    
                    Swal.fire(
                    'Cuidado!',
                    'Debe registrarse e iniciar sesión antes de continuar',
                    'warning'
                    )  
                }
                else if(this.envio == "caba" && this.shippingCost == null ){
                    
                    Swal.fire(
                    'Cuidado!',
                    'Seleccione un destino',
                    'warning'
                    )  
                }
                else{
                    this.$emit('update:step',1)
                    this.$emit('update:envio2',this.envio)
                }
            }
            
        }

    }
</script>

<style lang="scss" scoped>

    .cp{
        border: 1px solid rgba(51, 51, 51, 0.15);
        border-radius: 8px;
        padding:10px;
        margin-bottom:10px;
    }


    .section-envio{
        padding:0px 22px 39px 22px;
    }

    h3{
        font: normal normal normal 24px/28px Open Sans;
        font-weight: 500;
        margin-bottom:0;
    }

    .section-envio h4{
        font: normal normal normal 20px/24px Open Sans;
        font-weight: 500;
        margin-bottom:0px;
    }

    .section-envio .total {
        font: normal normal bold 20px/24px Open Sans;
    }

    .section-envio label{
        font: normal normal normal 20px/24px Open Sans;
    }

    .section-envio span{
        font: normal normal bold 22px/30px Open Sans;
        color: #FD914D;
    }

    .section-envio .precio{
        font: normal normal bold 22px/27px Open Sans;
        color: #FD914D;
    }

    hr{
        border: 0.5px solid rgba(143, 134, 110, 0.3);
    }

    .fila{
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top:13px;
    }


    button{
        text-align: center;
        font: normal normal bold 14px/17px Open Sans;
        letter-spacing: 0.56px;
        color: #FFFFFF;
        background: #FD914D 0% 0% no-repeat padding-box;
        border: 1px solid #FD914D;
        border-radius: 8px;
        padding-top: 11px;
        padding-bottom: 11px;
        width: 100%;
    }

 @media screen and (max-width: 800px) {
        .mt-10-mobile{
            margin-top: 10 !important;
        }
    }


</style>