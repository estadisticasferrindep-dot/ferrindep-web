
<template>
    <a class="carrito nav-link sin-borde" >
        <span v-show="itemsCount!=0" style="position: absolute;
    color: white;
    font: normal normal bold 10px/12px Open Sans;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    top: 30px;
    left: 24px;
    width: 15px;
    height: 15px;
    background-color: #FD914D;
    padding: 1px;
    cursor: pointer;"> {{itemsCount}} </span>

        <img :src="img" style="width: 40px;     margin-right: 9px;" >

        <div class="d-none d-md-flex">VER ORDEN DE COMPRA</div>
    </a>
</template>
<script>
//     import anime from 'animejs';

    export default {
        name: 'CartWidget',
       
        props:{
            img: {}
        },
        data() {
        return {
            itemsCount: 0,
            cart: []
        };
        },
        mounted() {
            this.$root.$on('count', data => {
                this.count();
            });
        },
        created() {
            this.count();
        },
        methods: {
            count(){
                console.log('entre')
                this.cart = JSON.parse(localStorage.getItem("cartQunuy")) || [];
                this.itemsCount = this.cart.length;
            }
        }
    }
</script>

<style>

.carrito {    
    position:relative;
    padding-left: 12px;
}

.carrito span {
    position: absolute;
    color: white;
    font: normal normal bold 10px/12px Open Sans;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    bottom: 37px;
    right: -5px;
    width: 15px;
    height: 15px;
    background-color: #A6CE39;
    padding: 1px;
    cursor: pointer;
}


.carrito i{
    width: 14px !important;
    height: 13px !important;
    color: #EEEEEE;
    font-size: 16px;
    cursor: pointer;
}

    @media screen and (max-width: 800px) {
        
        img{
            height: 39px !important;
            margin-top:0 !important;
        }
    } 

        
</style>