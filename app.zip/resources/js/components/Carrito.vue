
<template>
    <div class="row">
    <template v-if="step==0" >

        <div class="col-12 col-md-8">
                <cart-list :subtotal.sync="subtotal" />
        </div>
            
        <div  class="col-12 col-md-4">
                <checkout 
                    :ruta-productos="rutaProductos" 
                    :envios="envios"
                    :destinos="destinos"
                    :zonas="zonas"
                    :destinozonas="destinozonas"
                    :pesozonas="pesozonas"
                    :login="login"

                    :envio2.sync="envio"
                    :subtotal.sync="subtotal"
                    :target="target"
                    ref="checkout"
                    :parrafo-envio-fabrica="parrafoEnvioFabrica "
                    :parrafo-envio-interior="parrafoEnvioInterior "
                    :parrafo-envio-caba="parrafoEnvioCaba "
                    :parrafo-envio-expreso="parrafoEnvioExpreso "

                    :costo-envio-fabrica="costoEnvioFabrica "
                    :costo-envio-interior="costoEnvioInterior "
                    :costo-envio-caba.sync="costos"
                    :costo-envio-expreso="costoEnvioExpreso " 

                    :step.sync="step"
                    :total.sync="total"  :costoEnvio.sync="costoEnvio" :destinoId.sync="destinoId"
                />
        </div>
    
    </template>

    <finalizar-compra :envio.sync="envio" v-if="step==1" :total.sync="total"  :costoEnvio.sync="costoEnvio" :destinoId.sync="destinoId" :target="target"    
            :parrafo-efectivo="parrafoEfectivo"
            :parrafo-transferencia="parrafoTransferencia"
            :parrafo-mp="parrafoMp"
            :parrafo-envio-expreso="parrafoEnvioExpreso "
            :descuento-efectivo="descuentoEfectivo"
            :descuento-transferencia="descuentoTransferencia"
            :descuento-mp="descuentoMp"
            :costo-envio-fabrica="costoEnvioFabrica "
            :costo-envio-interior="costoEnvioInterior "
            :costo-envio-caba="costoEnvioCaba"
            :costo-envio-expreso="costoEnvioExpreso "

           :parrafo-envio-fabrica="parrafoEnvioFabrica "
            :parrafo-envio-interior="parrafoEnvioInterior "
            :parrafo-envio-caba="parrafoEnvioCaba "
            />
    </div>



</template>
<script>
    import CartList from './CartList.vue';
    import Checkout from './Checkout.vue';
    import FinalizarCompra from './FinalizarCompra.vue';



    export default {
        name: 'CartWidget',
        
        props:{
            rutaProductos: '',
            envios:{},

            login:{},
            destinos:{},
            zonas:{},
            destinozonas:{},
            pesozonas:{},

            img: {},
            target: {},
            parrafoEfectivo:{},
            parrafoTransferencia:{},
            parrafoMp:{},
            descuentoEfectivo:{},
            descuentoTransferencia:{},
            descuentoMp:{},


            parrafoEnvioFabrica: {type:String},
            parrafoEnvioInterior: {type:String},
            parrafoEnvioCaba: {type:String},
            parrafoEnvioExpreso: {type:String},

            costoEnvioFabrica: {type: Number},
            costoEnvioInterior: {type: Number},
            costoEnvioExpreso: {type: Number},
            costoEnvioCaba: {type: Number}
        },

        components:{
            'cart-list': CartList,
            'checkout': Checkout,
            'finalizar-compra': FinalizarCompra

        },
        data() {
            return {
                itemsCount: 0,
                cart: [],
                step:0,
                subtotal:0,
                total:0,
                envio:'',
                costoEnvio:0,
                destinoId:0,

                costos:{
                    envioCaba:this.costoEnvioCaba
                }
            };
        },
        created() {
            this.count();
        },
        methods: {
            count(){
                this.cart = JSON.parse(localStorage.getItem("cartQunuy")) || [];
                this.itemsCount = this.cart.length;
            }
        }
    }
</script>

<style>

.carrito {    
    position:relative;
    padding-left: 12px;
}

.carrito span{
    position: absolute;
    color:white;
    font: normal normal bold 10px/12px Rubik;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    bottom: 4px;
    right: 10px;
    width: 17px;
    height: 17px;
    background-color:#8F866D;
    padding:1px;
    cursor: pointer; 
}


.carrito i{
    width: 14px !important;
    height: 13px !important;
    color: #EEEEEE;
    font-size: 16px;
    cursor: pointer;
}

    @media screen and (max-width: 800px) {
        
        img{
            height: 39px !important;
            margin-top:0 !important;
        }
    } 

        
</style>