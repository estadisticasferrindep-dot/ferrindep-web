<template>

<div>
    <div v-if="presentaciones2.length >= 1">
        <div class="container-fluid" style="padding:0">
            
            <div class="col-12" >
                <div v-if="presentaciones2.length >= 1 && desde > 0">
                    <p class="precio" style="text-align: left; font: normal normal bold 17px/25px Open Sans;
                    letter-spacing: 0px;
                    color: #FD914D;
                    margin-bottom:0">
                            <span style="font: normal normal normal 15px/20px Open Sans;color: #333333;"></span>
                            <!-- <span v-if="parseFloat(oferta)" class="precio-oferta">
                                ${{desdeOferta}} x mt
                            </span> -->
                            $ {{desde}} - $ {{hasta}} <span v-if="conNombre  != 1"> x mt </span>
                    </p>
                </div>
                <div v-else>
                    <p class="precio" style="text-align: left; font: normal normal bold 25px/34px Open Sans;
                    letter-spacing: 0px;
                    color: #FD914D;
                    margin-bottom:0">
                            <span style="font: normal normal normal 15px/20px Open Sans;color: #333333;">Consultar precio</span>

                    </p>
                </div>
                    <div style="font: normal normal normal 12px/16px Open Sans; color: #FD914D; margin-top: 8px;"> Click para ver mas detalles</div>

            </div>
            <div class="col-12">
                <div class="w-100 d-flex justify-content-between" style="font: normal normal normal 11px/19px Open Sans;
                letter-spacing: 0px;
                color: #939292;
                margin-top: 3px;">
                    <div v-if="vendidos > 0 ">{{vendidos}} vendidos</div>

                    <div>
                        <h5  style="font: normal normal normal 11px/19px Open Sans; margin-bottom:0;" v-if="descEfectivo > 0 ">-{{descEfectivo}}% off efectivo</h5>
                        <h5  style="font: normal normal normal 11px/19px Open Sans; margin-bottom:0;" v-if="descTransferencia > 0 ">-{{descTransferencia}}% off transferencia</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>



</template>

<script>
    import Swal from 'sweetalert2';
    export default {
        name: 'AddToCartButton',
        props: { 
            price: {type: Number},
            presentaciones: {},
            oferta: {type: Boolean},
            precioAnterior: {type: Number},
            vendidos: {type: Number},
            descEfectivo: {type: Number},
            descTransferencia: {type: Number},
            descMp: {type: Number},
            conNombre: {type: Number}
        },
        data() { // lo que tengo de mi componente, sus datos, tambien las globales con window
            return {
                presentaciones2: {},
                presentacionElegido: null,
                desde:0,
                desdeOferta: 0,
                hasta:0

            };
        },
        created() { // lo que aparece cuando se crea el componente
            
            
            this.presentaciones2 = JSON.parse(this.presentaciones)
            console.log(this.presentaciones2)
            this.desdeCalcular()
            
        },
        methods: {
            desdeCalcular(){
                if(this.conNombre == 1){
                    let preciosXMetro  = this.presentaciones2.map(function(p) {
                        return p.precio;
                    });
                    this.desde = Math.min.apply(null, preciosXMetro)
                    this.hasta = Math.max.apply(null, preciosXMetro)


                    let preciosXMetroOferta  = this.presentaciones2.map(function(p) {
                        return p.precio_anterior;
                    });
                    this.desdeOferta = Math.min.apply(null, preciosXMetroOferta)
                }
                else{
                    let preciosXMetro  = this.presentaciones2.map(function(p) {
                        return Math.round((p.precio)/p.metros);
                    });
                    this.desde = Math.min.apply(null, preciosXMetro)
                    this.hasta = Math.max.apply(null, preciosXMetro)


                    let preciosXMetroOferta  = this.presentaciones2.map(function(p) {
                        return Math.round((p.precio_anterior)/p.metros);
                    });
                    this.desdeOferta = Math.min.apply(null, preciosXMetroOferta)
                }
                
            },
            selectpresentacion(presentacion){
                this.presentacionElegido = presentacion
                this.price= presentacion.precio
            },
            formatPrice(value) {
                let val = (value/1).toFixed(2).replace('.', ',')
                return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
            }
        },

        
    };
</script>

<style scoped>

    .presentacion {
        border: 1px solid #A6CE39;
        border-radius: 4px;
        font: normal normal 300 15px/18px Rubik;
        letter-spacing: 0px;
        color: #A6CE39;
        margin-right: 3;
        padding: 3 0 3 0;
        cursor:pointer;
        text-align: center;
        margin-bottom: 5px;
        width:47.5%;
    }


    .presentacion:hover, .presentacion.select{
        background: #A6CE39 0% 0% no-repeat padding-box;
        border: 1px solid #A6CE39;
        color: #FFFFFF;
    }




    .box-clase-mini{
        margin-top:22px;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        max-width: 95%;
        max-height: 95%;
        
        margin-right: calc(var(--bs-gutter-x)/ 2);
        margin-left: calc(var(--bs-gutter-x)/ 2);
        padding: 0;
    }

    .box-clase-mini .overlay{
        padding-bottom: 100%;
    }

    .box-clase-mini .overlay:hover{
        box-shadow: 0 0 0 9px #E9E9E9;
    }














    .add-to-cart-button {
        display: inline-block;
        padding: 0.4em 1em;
        border: none;
        font: inherit;
        font-size: 15px;
        text-transform: uppercase;
        color: #fff;
        background-color: #2f6410;
        cursor: pointer;
        transition: opacity 200ms ease;
    }
    .checkout-button {
        display: inline-block;
        padding: 0.4em 1em;
        border: none;
        font: inherit;
        font-size: 15px;
        text-transform: uppercase;
        border-top-right-radius: 25px;
        border-bottom-right-radius: 25px;
        color: #fff;
        background-color: #111282;
        cursor: pointer;
        transition: opacity 200ms ease;
    }

    .add-to-cart-button:hover {
        opacity: 0.75;
    }

    .col-3 {
        width: 23.5% !important;
    }
</style>