<template>
    <div>
    <h4 class="d-flex d-md-none" style="    font: 600 16px / 28px 'Open Sans'; margin-top:87px"> Detalle de su orden de compra:</h4>
    <table class="table" style=" border: 0.5px solid rgba(143, 134, 110, 0.3) ;     margin-top: 87px;">
        <thead class="d-none d-md-table-header-group"  style="">
            <tr style="font: normal normal normal 24px/28px Open Sans; font-weight:500">
                <td class="table-header" style=" border: 0.5px solid rgba(143, 134, 110, 0.3) !important;  padding:12px 22px 10px 22px;" >
                    Orden de compra
                </td>
                <td></td>
                <td></td>
                <td></td>
                <td class="d-none d-md-table-cell"></td>
            </tr>
        </thead>  

        <tbody>
            <tr v-for="(itemLista, key) in cart" :key="key" >
                <td scope="row"  style="display:flex; flex-direction:column; align-items:center; justify-content:center;" >  

                    <div class="imagen-carrito-mobile" :style="'border: 1px solid #CCCCCC; width:98px; height:103px; background-image: url('+ itemLista.imagen + ');background-repeat: no-repeat;background-position: center;background-size: contain;'" ></div>
                    <div class="borrar d-flex d-md-none" style="margin-bottom: 5px; cursor: pointer;" @click="borrarItem(key)">
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#999999" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="3 6 5 6 21 6"></polyline>
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
        <line x1="10" y1="11" x2="10" y2="17"></line>
        <line x1="14" y1="11" x2="14" y2="17"></line>
    </svg>
</div>
                
                </td>    
                <td class="nombre">
                     <h3 v-if="itemLista.conNombre" >{{itemLista.nombre}} ({{itemLista.ancho}})</h3>

                     <div v-else>
                        <h3  >{{itemLista.medidas + ' ' + itemLista.espesor}}</h3>
                        <h4 v-if="itemLista.ancho >= 100 ">{{itemLista.ancho/100}} m alto/ancho <spam v-if="itemLista.metros > 1">({{itemLista.metros}}m)</spam></h4>

                        <h4 v-else>{{itemLista.ancho}} cm alto/ancho<spam v-if="itemLista.metros > 1">({{itemLista.metros}}m)</spam></h4>
                     </div>
                    <h5 v-if="itemLista.free" style="font-size: 13px;
    color: green;"> (Envío gratis)</h5>
                </td>
                <td class="cantidad"><input type="number" min="1" v-model="itemLista.cantidad" :max="Math.min(Math.floor(itemLista.limite),itemLista.stock)"></td>
                <td class="total d-none d-md-table-cell">$ {{itemLista.precio * itemLista.cantidad | toCurrency}}</td>
                <td class="total d-table-cell d-md-none">$ {{itemLista.precio * itemLista.cantidad }}</td>

                <td class="borrar d-none d-md-table-cell" style="cursor: pointer;" @click="borrarItem(key)">
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#999999" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2">
        <polyline points="3 6 5 6 21 6"></polyline>
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
        <line x1="10" y1="11" x2="10" y2="17"></line>
        <line x1="14" y1="11" x2="14" y2="17"></line>
    </svg>
</td>
            </tr>
        </tbody>
    </table> 
    </div>               
</template>
<script>
    export default {

        props:{
            subtotal: {}
        },
        data() {
            return {
                cart: [],
                cargado: false
            }
        },
        watch:{
            cart: {
                handler(val){
                    if(this.cargado){
                        // this.redondear_cantidades(this.cart)
                        localStorage.setItem("cartQunuy",JSON.stringify(this.cart));
                        this.actualizar_subtotal(this.cart);
                    }
                },
                deep: true
            }
        },
        created() {
            this.cart = JSON.parse(localStorage.getItem('cartQunuy'));


            axios.get(window.publicPath()+'/cartdata', {
                params: {
                    cart: JSON.stringify( this.cart),
                }
            })
            .then((response) => {

                this.cart= response.data//devolver un array del carrito
                localStorage.removeItem("cartQunuy");

                this.cart.forEach(element => {
                    
                     localStorage.setItem("cartQunuy",JSON.stringify(element));

                });
                //borrar el localstorage y recorrer el array creando uno nuevo
            })


            // for (let index = 0; index < this.cart.length; index++) {
            //     item = this.cart[index]
                
            //     if (item.cantidad > item.limite || item.cantidad > item.stock) { 
            //         item.cantidad = Math.min(item.limite,item.stock)
            //     }
            // }
            // localStorage.setItem("cartQunuy",JSON.stringify(this.cart));
            // this.cart = JSON.parse(localStorage.getItem('cartQunuy'));
            

            this.cargado = true;
        },
        methods: {
            redondear_cantidades(cartActualizado){

                for (let index = 0; index < this.cartActualizado.length; index++) {
                    let item = cartActualizado[index]

                    if (item.cantidad > 0) {
                        item.cantidad = Math.round(item.cantidad)
                        
                    }
                    
                }
            },
            borrarItem(key){
                this.cart.splice(key, 1)
                // this.$root.$refs.cart.count();
                // this.$parent.$refs.checkout.seAnulaEnvio();
                this.$root.$emit('seAnulaEnvio','data');
                this.$root.$emit('count','data');

            },
            // elegirRango(item){
            //     let cant = item.cantidad
            //     let rang = item.rangos

            //     for (let index = 0; index < rang.length; index++) {
            //         if(index != rang.length -1){
            //             if (rang[rang.length-2-index].max < cant){
            //                 return rang[rang.length-1-index]
            //             }
            //         }
            //         else{
            //             return rang[0]
            //         }
            //     }
            // },
            actualizar_subtotal(cartActualizado){
                let subtotal = 0
                
                this.precios = []
                // cartActualizado.forEach((item) => {
                //                 this.precios.push(item.price * item.cantidad);
                //             });

                // cartActualizado.forEach((item) => {
                //                 this.precios.push(this.elegirRango(item).precio * item.cantidad);
                //                 console.log(this.elegirRango(item).precio)
                //             });

                cartActualizado.forEach((item) => {
                                this.precios.push(item.precio * item.cantidad);
                            });

                for (var i = 0; i < this.precios.length; i++){			
                    subtotal +=  this.precios[i];
                }

                this.$emit('update:subtotal',subtotal)
                // this.calculo_iva()
                // this.calculo_descuento_pago()
                // this.calculo_envio()
                // this.calculo_total()
            },
            toCart(){
                window.location.href = "/cart"
            }
        }

    }
</script>

<style lang="scss" scoped>

    .table>:not(caption)>*>* {
        border:none;
    }

    .section-carrito tbody .btn-x{
        width: 20px;
        height: 20px;
        background-color:transparent;
        margin-right:21px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor:pointer;
        font-size:19px;
        color: #FD914D;
    }

    .cantidad input{
        border: 1px solid rgba(143, 134, 110, 0.3);
        width: 81px;
        border-radius: 10px;
        text-align: left;
        font: normal normal normal 14px/23px Open Sans;
        color: #8F866D;
        padding:6px;
        padding-left:15px;
    }

    .table-header{
        column-span: all;
    }

    
    .section-carrito tbody td{
        text-align: left;
        letter-spacing: 0px;
        padding:13px;
        vertical-align: middle !important;
    }


    @media screen and (max-width: 800px) {
        .cantidad input{
            width: 50px;
        }

        .section-carrito tbody .cantidad{
            padding-left: 0;
            padding-right: 0;
        }
        
        .section-carrito tbody .total{
            padding-right: 0;
        }

        .section-carrito tbody .nombre{          
            width: 117px;
        }

        .section-carrito tbody .borrar{
            padding-right: 0;
        }

        .section-carrito tbody td{
            padding: 0;
        }

        .imagen-carrito-mobile{
            border:none !important;
            width: 56px !important;
            height: 86px !important;
        }

        .section-carrito h3, .section-carrito h4{
            font-size:12px !important;
        }

        table{
            margin:0 !important;
            border:none !important;
        }

        tr{
            border: none !important;
            border-bottom: 0.5px solid rgba(143, 134, 110, 0.3) !important;
            border-top: 0.5px solid rgba(143, 134, 110, 0.3) !important;

        }

    }



    @media screen and (min-width: 768px){
        .d-md-table-header-group {
                display: table-header-group !important;
        }
    }
    

    .section-carrito tbody input:focus-visible{

        outline:0 !important;
    }

    .total{
        font: normal normal bold 25px/34px Open Sans;
        color: #FD914D;
        white-space: nowrap;
        font-size:18px;
    }

    td h3{
        font: normal normal normal 20px/24px Open Sans;
    }

    td h4{
        font: normal normal normal 13px/15px Open Sans;
    }


    .section-carrito thead th{
        letter-spacing: 0.75px;
        text-align:right;
        padding:19px;
    }


    tr{
        border: 0.5px solid rgba(143, 134, 110, 0.3);
    }
</style>