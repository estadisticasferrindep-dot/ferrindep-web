<template>
    <div>
        <div v-if="loading"><i class="fa fa-spinner fa-spin"></i></div>
        <div class="correo-argetino-box__form" v-else>
            <select name="" class="form-control mb-2" v-model="destino_id">
                <option :value="null">Seleccione un Destino</option>
                <option v-for="destino in destinos" :value="destino.nombre" :key="destino.id">{{ destino.nombre }}</option>
            </select>
            <div class="input-group mb-2" v-if="destino_id">
                <span class="input-group-text">Total $</span>
                <div class="form-control">{{ getCaculatedShipping | toCurrency }} <span v-if="getCaculatedShipping == 0" style="font-size: 13px;
    color: green; font-weight:bold;"> (Envío gratis)</span></div>
                
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {},
    data() {
        return {
            loading: false,
            destinos: [],
            zonas: [],
            pesozonas: [],
            cart: [],
            destino_id: null,
        }
    },
    created() {
        setInterval(() => {
            this.getCart()
        }, 500)
        this.getData();
    },
    methods: {
        getData() {
            this.loading = true;
            axios.get(this.$root.publicPath + '/api/carrito')
                .then(response => {
                    this.destinos = response.data.destinos;
                    this.zonas = response.data.zonas;
                    this.pesozonas = response.data.pesozonas;

                    this.loading = false;
                })
                .catch(error => {
                    console.log(error);
                });
        },
        getCart() {
            this.cart = JSON.parse(localStorage.getItem('cartQunuy'));
        }
    },
    computed: {
        getCaculatedShipping() {
            let destino = this.destinos.find(destino => destino.nombre == this.destino_id);
            if ( !destino ) {
                return 0;
            }
            // aca son los paquentes que se van a enviar
            // es un array, cada uno no puede exceder el peso maximo que son 25 por cada uno
            let packages = [];
            // aca itero los elementos del carrito
            if ( this.cart.length > 0 ) {
                this.cart.forEach(item => {
                    // defino la variable packageFound que por defecto va en false
                    // esto significa que no ha encontrado ningun paquete que cumpla con el peso maximo
                    let packageFound = false
                    // calculo el peso, que es una multiplicacion de la cantidad por el peso del producto
                    let weight = item.cantidad * item.peso;
                    // itero los paquetes que ya se han creado
                    // esto es para saber si el paquete entra en uno de los paquetes creados
                    packages.forEach(p => {
                        // aca va a validar que el peso del paquete no exceda el peso maximo
                        // y que si el paquete tiene envio gratis al igual que el item a agregar
                        if ( (p.total_size + weight) <= 25 && (!!item.free) == p.free ) {
                            // de encontrar un lugar que cumpla con el peso maximo
                            // la variable packageFound va a cambiar a true
                            packageFound = true;
                            // y sumo el peso al paquete que encontre
                            p.total_size += weight;
                        }
                    });
                    // chequeo si no se encontro ningun paquete que cumpla con el peso maximo
                    // de ser asi esta es la logica para crearlo
                    if ( !packageFound ) {
                        // chequeo si el producto se pasa de los 25kg
                        if ( weight > 25 ) {
                            // si el paquete de pasa de 25kg,
                            // entonces divido en grupos de 25kg
                            // por ejemplo si el producto pesa 60kg,
                            // packs tendra 2 paquetes, uno de 25kg y otro de 25kg
                            // y remainder tendra un paquete de 10kg
                            let packs = Math.floor(weight / 25);
                            let remainder = weight % 25;
                            for (let i = 0; i < packs; i++) {
                                packages.push({
                                    total_size: 25,
                                    cost: 0,
                                    free: !!item.free
                                });
                            }
                            if ( remainder > 0 ) {
                                packages.push({
                                    total_size: remainder,
                                    cost: 0,
                                    free: !!item.free
                                });
                            }

                        } else {
                            // de no pasar el peso maximo, creo un paquete con el peso del producto
                            packages.push({
                                total_size: item.cantidad * item.peso,
                                cost: 0,
                                free: !!item.free
                            })
                        }
                    }
                });
            }

            packages.forEach(p => {
                this.pesozonas.forEach(z => {
                    if ( p.total_size <= z.peso && z.zona_id == destino.zona_id && p.free == false ) {
                        p.cost = parseFloat(z.costo);
                    }
                });
            });
            let total = packages.reduce((a, b) => a + b.cost, 0);
            this.$emit('shipping-cost', total);
            this.$emit('destino_id',  this.destino_id);

            return total;
        }
    }
}
</script>

<style lang="scss" scoped>
    .correo-argetino-box {
        &__form {
            padding: 7.5px;
            border: 1px solid rgba(143, 134, 110, 0.3);
            margin: 7.5px 0;
        }
    }
    .input-group-text {
        background-color: #fff;
    }
</style>