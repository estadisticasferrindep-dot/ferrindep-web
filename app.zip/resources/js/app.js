/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');


window.publicPath = () => {
    let meta = document.querySelector('meta[name="public-path"]');
    if (meta) {
        return meta.getAttribute('content').replace(/\/$/, '');
    }
    return '';
};
window.Vue = require('vue').default;

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i)
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default))


Vue.component('add-to-cart', require('./components/AddToCart.vue').default);
Vue.component('cart', require('./components/Cart.vue').default);
Vue.component('carrito', require('./components/Carrito.vue').default);

Vue.component('cart-list', require('./components/CartList.vue').default);
Vue.component('checkout', require('./components/Checkout.vue').default);
Vue.component('finalizar-compra', require('./components/FinalizarCompra.vue').default);


Vue.component('galeria-producto', require('./components/GaleriaProducto.vue').default);

Vue.component('diametros-categorias', require('./components/DiametrosCategorias.vue').default);

Vue.component('rangos-categorias', require('./components/RangosCategorias.vue').default);

Vue.component('desde-categorias', require('./components/DesdeCategorias.vue').default);

Vue.component('nombre-hover', require('./components/NombreHover.vue').default);


Vue.component('login', require('./components/Login.vue').default);
Vue.component('registro', require('./components/Registro.vue').default);


/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

window.toCurrency = (numero) => {  //la pongo aca para que pueda usarla desde cualquier lado
    let decimales = 2

    let separadorDecimal = document.head.querySelector('meta[name="decimal-separator"]');
    if (separadorDecimal) {
        separadorDecimal = separadorDecimal.content;
    } else {
        separadorDecimal = ','
    }

    let separadorMiles = document.head.querySelector('meta[name="thousands-separator"]');
    if (separadorMiles) {
        separadorMiles = separadorMiles.content;
    } else {
        separadorMiles = '.'
    }

    let partes, array;

    if ( !isFinite(numero) || isNaN(numero = parseFloat(numero)) ) {
        return "";
    }
    if (typeof separadorDecimal==="undefined") {
        separadorDecimal = ",";
    }
    if (typeof separadorMiles==="undefined") {
        separadorMiles = "";
    }

    // Redondeamos
    if ( !isNaN(parseInt(decimales)) ) {
        if (decimales >= 0) {
            numero = numero.toFixed(decimales);
        } else {
            numero = (
                Math.round(numero / Math.pow(10, Math.abs(decimales))) * Math.pow(10, Math.abs(decimales))
            ).toFixed();
        }
    } else {
        numero = numero.toString();
    }

    // Damos formato
    partes = numero.split(".", 2);
    array = partes[0].split("");
    for (var i=array.length-3; i>0 && array[i-1]!=="-"; i-=3) {
        array.splice(i, 0, separadorMiles);
    }
    numero = array.join("");

    if (partes.length>1) {
        numero += separadorDecimal + partes[1];
    }

    return numero;
}

Vue.filter('toCurrency',window.toCurrency);


const app = new Vue({
    el: '#app',
    data: {
        publicPath: window.publicPath(),
    }
});


