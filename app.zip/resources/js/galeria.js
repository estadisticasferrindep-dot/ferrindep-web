

document.addEventListener('DOMContentLoaded',function(){

    let contador = 0

    const overlay = document.querySelector('.slideshow')
    const overlay = document.querySelector('.overlay-galeria')
    const galeria_imagenes = document.querySelector('.galeria img')
    const img_slideshow = document.querySelector('.slideshow img')




})